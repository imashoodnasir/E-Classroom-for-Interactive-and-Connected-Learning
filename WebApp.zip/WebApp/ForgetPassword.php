<?php
	require("CheckValidity.php");
?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Login</title>
		
		<?php
			require("includes/meta.php");
		?>

	</head>
<body>

<?php
	require("includes/Header.php");
?>

<section id="content">
  <div class="container">
    <div class="row">
      
      <div class="grid_5">
      <div class="grid_12">
        <h3 class="head__1">Login Form<span style="font-size: 18px; float: right"><a href="Login.php">Back</a></span></h3> 
        <div class="fwn">
          <p>Kindly provide username and password to access your account.</p>
          <p>If you have problems with login, you can <a href="contacts.php" rel="nofollow" class="color1">Click here</a> to contact us.</p>
        </div>
              <form id="contact-form" method="POST">
                  <div class="contact-form-loader"></div>
                  <fieldset>
                    <label class="name">
                      <input type="text" class="required" required name="Username" placeholder="Registered Username:" value=""/>
                    </label><br/><br/><br/>
                   
                  </fieldset> 
				  <input type="submit" class="btn" name="Forget" value="Retrieve Password" style="float: left; cursor:pointer;">
                </form>   
      </div>
    </div>
  </div>
</section>

<?php
	require("includes/footer.php");
?>

<a href="#" id="toTop" class="fa fa-chevron-up"></a>
</body>
</html>

<?php
	if(isset($_POST['Forget']))
	{
		$Username = $_POST['Username'];
		require("includes/db_connection.php");
		$query=mysql_query("SELECT * FROM tblusers WHERE Username='$Username'");
		$row = mysql_fetch_array($query);
		if(is_array($row)) 
		{
			$FirstName = $row['FirstName'];
			$LastName = $row['LastName'];
			$Password = $row['Password'];
			$Email = $row['Email'];
			session_start();
			$_SESSION['from'] = 'inzamamgee@gmail.com';
			$_SESSION['to'] = $Email;
			$_SESSION['subject'] = 'Request Password';
			$_SESSION['body'] = "Hello $FirstName $LastName,\n\nRecently, you clicked on the forget password. Here is your password:\n";
			$_SESSION['body'] .= "Password: $Password\n\n";
			$_SESSION['body'] .= "Thank you for contacting us.\n\n";
			$_SESSION['body'] .= "Regards:\n";
			$_SESSION['body'] .= "Team E-Classroom.";
			require_once "SendMail.php";
		}
	}
?>