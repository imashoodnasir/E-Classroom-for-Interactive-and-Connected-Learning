<?php
	$hostname = "localhost";
	//$username = "root";
	$username = "inzzooco_project";
	//$password = "";
	$password = "projects_testing";
	//$db_name = "eclassroom";
	$db_name = "inzzooco_eclass";
	
	$con = mysql_connect($hostname,$username, $password);
	if($con)
	{
		mysql_select_db($db_name) or die("Database Not Found");
	}
	else
		die("Connection is not Established!");
?>