<div class="alert fade in" style="display:none;">
	<a href="" class="close" aria-label="close" title="close">×</a>
	<strong>Alert! </strong><span id="spnalertMsg"></span>
</div>
<div class="container">
    <div class="row">
      <div class="grid_12 rel">
        <h1>
          <a href="index.php">
            <img style="width: 220px; height: 70px;" src="images/logo.png" alt="Logo alt">
          </a>
        </h1>
      </div>
    </div>
  </div>
  <section id="stuck_container" style="background-color: #00B1BA;">

    <div class="container">
      <div class="row">
        <div class="grid_12 ">
          <div class="navigation ">
            <nav>
              <ul class="sf-menu">
               <li><a href="index.php">Home</a></li>
               <li><a href="about.php">About</a></li>
               <li><a href="contacts.php">Contacts</a></li>
			   <?php
					if(isset($_SESSION['Name']))
					{
						$ProfilePicture = $_SESSION['ProfilePic'];
						$username = $_SESSION['Name'];
						echo "<li style='float: right'><img id='imgcircle' src='images/userPicture/$ProfilePicture' style='height: 50px; width: 50px; margin-top: -9px;; cursor: pointer; border-radius: 70%;'></li>
						<li style='float: right'><strong><span style='color: #D62020;color: white; font-size: 26px;'>$username</strong></span></li>";
					}
					else
					{
						echo "<li style='float: right'><a href='Login.php'>Login</a></li>";
					}
			   ?>
             </ul>
            </nav>
            <div class="clear"></div>
          </div>       
         <div class="clear"></div>  
        </div>
     </div> 
    </div> 
	<?php
		if(isset($_SESSION['Name']) && isset($_SESSION['Role']))
		{
			echo "<div id='stuck_container1' style='display: none; background-color: #088389; box-shadow: 10px 10px 5px #888888; border-top: 1px solid white; border-bottom: 1px solid white;width: 230px; right:0;margin-right: 80px;height: 100px; position:absolute'>";
			echo "<br/><a style='font-size: 20px; margin-left: 20px; line-height: 40px;' href='Logout.php'>Logout</a>";
			echo "</div>";
		}
	?>
  </section>