<meta charset="utf-8">
<meta name="format-detection" content="telephone=no" />
<link rel="icon" href="images/favicon.ico">
<link rel="shortcut icon" href="images/favicon.ico" />
<link rel="stylesheet" href="css/contact-form.css">
<link rel="stylesheet" href="css/style.css">
<script src="js/jquery.js"></script>
<script src="js/jquery-migrate-1.1.1.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/script.js"></script> 
<script src="js/superfish.js"></script>
<script src="js/jquery.equalheights.js"></script>
<script src="js/jquery.mobilemenu.js"></script>
<script src="js/tmStickUp.js"></script>
<script src="js/jquery.ui.totop.js"></script>
<script src="js/modal.js"></script>
<link href='http://fonts.googleapis.com/css?family=Raleway:400,200' rel='stylesheet' type='text/css'> 
<link href="//netdna.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css" rel="stylesheet">
<script>
 $(window).load(function(){
  $().UItoTop({ easingType: 'easeOutQuart' });
  $('#stuck_container').tmStickUp({});  
 });
 
 $(document).ready(function(){
	 $('#imgcircle').click(function(){
		 $('#stuck_container1').slideToggle(200);
	 });
	 $(".alert .close").click(function () {
                $(".alert").fadeOut(500);
            });
	 $("body").click(function (e) {
		var container = $("#stuck_container1");
		var containertext = $('#imgcircle');
		if (!container.is(e.target) && container.has(e.target).length === 0 && !containertext.is(e.target) && containertext.has(e.target).length === 0) {
			container.slideUp();
		}
	});
 });
 
function showSuccessMessage(msg)
 {
	 $(".alert").addClass('alert-success');
	 $(".alert").removeClass('alert-danger');
	 $('#spnalertMsg').html(msg);
	  $(".alert").show(500);
 }
 
 function showErrorMessage(msg)
 {
	 $(".alert").removeClass('alert-success');
	 $(".alert").addClass('alert-danger');
	$('#spnalertMsg').html(msg);	 
	$(".alert").show(500);
 }
 
 function getQueryString(qString) {
    var queryString = decodeURI(location.search);
    if (queryString.length == 0)
        return;
    queryString = queryString.substr(1);

    var qPair = queryString.split("&");

    for (var i = 0; i < qPair.length; i++) {
        var pair = qPair[i].split("=");
        if (pair[0] == qString)
            return pair[1];
    }
}
</script>
