<footer id="footer">
  <div class="container">
    <div class="row">
      <div class="grid_12"> 
        <div class="copyright"><span class="brand">EClassroom</span> &copy; <span id="copyright-year"></span> | <a href="Privacy.php">Privacy Policy</a>
          <div class="sub-copy">Website designed and Developed by <a href="http://www.inzzoo.com/" rel="nofollow">Inzamam Mashood Nasir</a></div>
        </div>
      </div>
    </div>
  </div>  
</footer>
<a href="#" id="toTop" class="fa fa-chevron-up"></a>