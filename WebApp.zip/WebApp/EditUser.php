<?php
	require("Login_Check.php");
	if($_SESSION['User_Role'] != 'Admin')
		header("Location:Login.php");
	include("includes/db_connection.php");
	if(isset($_GET['i']))
	{
		$User_ID = $_GET['i'];
		$query = "SELECT * FROM tblusers WHERE User_ID='$User_ID'";
		$status = mysql_query($query);
		IF($row = mysql_fetch_array($status))
		{
			$Username= $row['Username'];
			$RegNo= $row['RegNo'];
			$Email = $row['Email'];
			$Role = $row['Role'];
			$Phone = $row['Phone'];
		}
	}
?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Add New User</title>
		<?php
			require("includes/meta.php");
		?>
	</head>
	<body>

	<?php
		require("includes/Header.php");
	?>

	<section id="content">
	  <div class="container">
		<div class="row">
		  
		  <div class="grid_5">
		  <div class="grid_12">
			<h3 class="head__1">Add New User <span style="font-size: 18px; float: right"><a href="ManageUsers.php">Back to Users</a></span></h3>
			<div class="fwn">
			  <p>Kindly fill out the following form to Add New User.</p>
			  <p>If you have problems with updation, you can <a href="contacts.php" rel="nofollow" class="color1">Click here</a> to contact us.</p>
			</div>
				  <form id="contact-form" method="POST" enctype="multipart/form-data">
					  <div class="contact-form-loader"></div>
					  <fieldset>
						<p>Fill the Following information to add new user.</p>
						<label class="phone">
						  <input type="text" class="required" name="RegNo" placeholder="Registration No:" value="<?php echo $RegNo;?>" />
						</label>
						
						<label class="name">
						  <input type="text" class="required" name="Username" placeholder="Username" value="<?php echo $Username;?>"/>
						</label>
						
						<label class="name" style=" width: 270px;">
							<select name="Role" class="required">
								<option class="required" disabled>--SELECT Role--</option>
								<?php
									include("includes/db_connection.php");
									$query = "SELECT * FROM tblroles WHERE isActive='Yes'";
									$status = mysql_query($query);
									WHILE($row = mysql_fetch_array($status))
									{
										$ID = $row['ID'];
										$RoleTitle = $row['RoleTitle'];
										if($Role == $ID)
											echo "<option selected value='$ID'>$RoleTitle</option>";
										else
											echo "<option value='$ID'>$RoleTitle</option>";
									}
								?>
							</select>
						</label>
						
						<label class="name"  style="margin-left: 0px">
						  <input type="email" class="required" name="Email" placeholder="Email:" value="<?php echo $Email;?>" />
						</label>
						
						<label class="name" >
						  <input type="text" class="required" name="Phone" placeholder="Phone:" onkeypress="return ValidateOnlyNumber(event);" value="<?php echo $Phone;?>" />
						</label>
						
						<div class="clear"></div>
						<div>
							
						  <input type="submit" class="btn" name="Update" onclick="return ValidateForm();" value="Add New User" style="float: left; cursor:pointer;">
						</div>
					  </fieldset> 
					</form>   
		  </div>
		</div>
	  </div>
	</section>

	<?php
		require("includes/footer.php");
	?>

	<a href="#" id="toTop" class="fa fa-chevron-up"></a>
	</body>
</html>

<?php
	if(isset($_POST['Update']))
	{
		$RegNo = $_POST['RegNo'];
		$Username = $_POST['Username'];
		$Email = $_POST['Email'];
		$Role = $_POST['Role'];
		$Phone = $_POST['Phone'];

		$query = "UPDATE tblusers SET RegNo ='$RegNo', Username='$Username' Email=$Email', Role='$Role', Phone='$Phone' WHERE User_ID='$User_ID'";
		$status = mysql_query($query);
		if($status)
			echo "<script>showSuccessMessage('User Successfully Updated!')</script>";
		else
			echo "<script>showErrorMessage('User is not Successfully Updated!')</script>";
	}
?>