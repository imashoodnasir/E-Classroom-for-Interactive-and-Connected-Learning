<?php
	require("Login_Check.php");
	include("includes/db_connection.php");
	if(isset($_SESSION['User_ID']))
	{
		$User_ID = $_SESSION['User_ID'];
		$query = "SELECT  u.*, r.RoleTitle FROM tblusers u join tblroles r on u.Role = r.ID WHERE u.User_ID='$User_ID'";
		$status = mysql_query($query);
		IF($row = mysql_fetch_array($status))
		{
			$FirstName = $row['FirstName'];
			$LastName = $row['LastName'];
			$Username = $row['Username'];
			$RegNo = $row['RegNo'];
			$Email = $row['Email'];
			$ProfilePic = $row['ProfilePic'];
			$RoleTitle = $row['RoleTitle'];
		}
	}
	
?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>Upload Documents</title>

<?php
	require("includes/meta.php");
?>

</head>
<body>

<?php
	require("includes/Header.php");
?>

<section id="content"><div class="ic"></div>
  <div class="container">
    <div class="row">
      <div class="grid_12">
        <h3 style="line-height: 0px; margin-bottom: 40px;">Student Profile</h3>
        <div style="width: 25%; float: left;">
		<img src="images/userPicture/<?php echo $ProfilePic;?>" style="height: 180px; margin-bottom: 20px;" alt="" class="img_inner fleft">
		<table style="width:100%">
				<tr>
					<td><p class="fwn">Registration No: <strong><?php echo $RegNo;?></strong></p></td>
				</tr>
				<tr>
					<td><p class="fwn">Username: <strong><?php echo $Username;?></strong></p></td>
				</tr>
				<tr>
					<td><p class="fwn">Email: <strong><?php echo $Email;?></strong></p></td>
				</tr>
				<tr>
					<td><p class="fwn"><a href="editProfile.php">Edit Profile</p></td>
				</tr>
				<tr>
					<td><p class="fwn"><a href="forgetPassword.php">Change Password</p></td>
				</tr>
			</table>
			</div>
        <div class="extra_wrapper"  style="width: 70%; float: right;">
          <blockquote class="bq1">
            <h3 style="padding-top: 0px; margin-bottom: -20px;">Upload Document <span style="font-size: 18px; float: right"><a href="ProfileStudent.php">Back to Profile</a></span></h3>
            <form method="POST" id="contact-form" enctype="multipart/form-data">
				<div class="contact-form-loader"></div>
				<fieldset>
					<label class="name" style="width: 270px;">
						<input type="text" class="required" name="FileName" placeholder="File Name:" value=""/>
					</label>
					<label class="name">
						<input type="file" class="btnfile" accept="application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document" required name="DocumentFile" style=" width: 336px; margin-bottom: 30px;"/>
					</label>
					<label class="name" style="margin-left: 0px; width: 270px;">
					  <select name="Subject" class="required">
						<option selected class="required" disabled>--SELECT Subject--</option>
						<?php
							include("includes/db_connection.php");
							$query = "SELECT * FROM tblsubjects WHERE isActive='Yes'";
							$status = mysql_query($query);
							WHILE($row = mysql_fetch_array($status))
							{
								$ID = $row['ID'];
								$Subject_Title = $row['Subject_Title'];
								echo "<option value='$ID'>$Subject_Title</option>";
							}
						?>
						</select>
					</label>
					<div style="width: 100%; float: left;">
						<input type="submit" class="btn" name="Upload" value="Upload" onclick="return ValidateForm();" style="margin-top: -20px; float: left; cursor:pointer;"/>
					</div>
				</fieldset>
			</form>
			<table width="100%" style="margin-top: 20px; border-collapse: initial; border-spacing: 3px;" border="1">
				<tr style="background-color: #00B1BA; color: white;">
					<th>No.</th>
					<th>Document's Name</th>
					<th>Subject</th>
					<th>Upload Date</th>
					<th>Action</th>
				</tr>
				<?php
					$count= 0;
					$query = "SELECT l.*, s.Subject_Title FROM tbllibrary l join tblsubjects s on l.Subject_ID = s.ID WHERE l.User_ID='$User_ID'";
					$status = mysql_query($query);
					WHILE($row = mysql_fetch_array($status))
					{
						$ID = $row['ID'];
						$DocumentName = $row['DocumentName'];
						$Subject_Title = $row['Subject_Title'];
						$UploadDate = $row['UploadDate'];
						$count++;
						if(($count%2) == 0)
							$class="even";
						else
							$class="odd";
						echo "<tr class='$class'>
								<td>$count</td>
								<td><a href='view.php?i=$ID'><u>$DocumentName</u></a></td>
								<td>$Subject_Title</td>
								<td>$UploadDate</td>
								<td><a href='DeleteDoc.php?i=$ID'  onclick='return deleletconfig()'><u>Delete</u></td>
							</tr>";
					}
				?>
			</table>
          </blockquote>
        </div>
      </div>
    </div>
  </div>
</section>

<?php
	require("includes/footer.php");
?>

<a href="#" id="toTop" class="fa fa-chevron-up"></a>
</body>
</html>

<?php
	if(isset($_POST['Upload']))
	{
		$FileName = $_POST['FileName'];
		$Subject_ID = $_POST['Subject'];
		if(isset($_FILES['DocumentFile']))
		{
			$random_key = substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 30);
			$DocumentFile = $_FILES['DocumentFile']['name'];
			$temp_name= $_FILES['DocumentFile']['tmp_name'];
			move_uploaded_file($temp_name, "User_Documents/$DocumentFile");
			$DocumentFile = "$DocumentFile";
			$offset=5*60*60;
			$dateFormat="d-m-Y H:i:s";
			$CurrentDateTime=gmdate($dateFormat, time()+$offset);
		}
		$query = "INSERT INTO tbllibrary (User_ID, Subject_ID, DocumentFile, DocumentName, UploadDate) VALUES ('$User_ID', '$Subject_ID', '$DocumentFile', '$FileName', '$CurrentDateTime')";
		$status = mysql_query($query);
		if($status)
		{
			echo "<meta http-equiv='refresh' content='0'>";
		}
	}
?>