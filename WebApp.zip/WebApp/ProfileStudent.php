<?php
	require("Login_Check.php");
	include("includes/db_connection.php");
	if(isset($_SESSION['User_ID']))
	{
		$User_ID = $_SESSION['User_ID'];
		$query = "SELECT  u.*, r.RoleTitle FROM tblusers u join tblroles r on u.Role = r.ID WHERE u.User_ID='$User_ID'";
		$status = mysql_query($query);
		IF($row = mysql_fetch_array($status))
		{
			$FirstName = $row['FirstName'];
			$LastName = $row['LastName'];
			$Username = $row['Username'];
			$RegNo = $row['RegNo'];
			$Email = $row['Email'];
			$ProfilePic = $row['ProfilePic'];
			$RoleTitle = $row['RoleTitle'];
		}
	}
	
?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>Student Profile</title>

<?php
	require("includes/meta.php");
?>

</head>
<body>

<?php
	require("includes/Header.php");
?>

<section id="content"><div class="ic"></div>
  <div class="container">
    <div class="row">
      <div class="grid_12">
        <h3 style="line-height: 0px; margin-bottom: 40px;">Student Profile</h3>
        <div style="width: 25%; float: left;">
		<img src="images/userPicture/<?php echo $ProfilePic;?>" style="height: 180px; margin-bottom: 20px;" alt="" class="img_inner fleft">
		<table style="width:100%">
				<tr>
					<td><p class="fwn">Registration No: <strong><?php echo $RegNo;?></strong></p></td>
				</tr>
				<tr>
					<td><p class="fwn">Username: <strong><?php echo $Username;?></strong></p></td>
				</tr>
				<tr>
					<td><p class="fwn">Email: <strong><?php echo $Email;?></strong></p></td>
				</tr>
				<tr>
					<td><p class="fwn"><a href="editProfile.php">Edit Profile</p></td>
				</tr>
				<tr>
					<td><p class="fwn"><a href="ChangePassword.php">Change Password</p></td>
				</tr>
				<tr>
					<td><p class="fwn"><a href="ChangeProfileUser.php">Change Profile Picture</p></td>
				</tr>
			</table>
			</div>
        <div class="extra_wrapper"  style="width: 70%; float: right;">
          <blockquote class="bq1">
            <p style="font-size: 18px;"> You can ask a question and your question will be answered by your community once it is accepted by admin or your teacher. Answers are also validated before they are published to give the best possible results to the users. </p>
            <a href="AskQuestion.php"><span class="profilelink">Ask Question</span></a>
          </blockquote>
		  <blockquote class="bq1">
            <p style="font-size: 18px;">Want to write some quick notes and save them, to use during class? Here is the editor for you to make quick notes and you can access it using the windows application from the classroom.</p>
            <a href="UploadNotes.php"><span class="profilelink">Upload Notes</span></a>
          </blockquote>
          <blockquote class="bq1">
            <p style="font-size: 18px;">Have some notes or files, which can be helpful during class? Upload those files in your account and use them during class via our Windows Application. You can add Text Files (*.txt), Word Files (*.doc or *.docx) and PDF Files (*.pdf).</p>
            <a href="UploadDocuments.php"><span class="profilelink">Upload Documents</span></a>
          </blockquote>
        </div>
      </div>
    </div>
  </div>
</section>

<?php
	require("includes/footer.php");
?>

<a href="#" id="toTop" class="fa fa-chevron-up"></a>
</body>
</html>