<?php
	error_reporting(0);
	@ini_set('display_errors', 0);
	session_start();
	if(!isset($_SESSION['Name']))
	{
		session_destroy();
		header("Location:Login.php");
	}
	
	//Auto Logout after 15 minutes of inactivity..
	
	$timeout = 15;
	$logout_redirect_url = "login.php";

	$timeout = $timeout * 60;
	if (isset($_SESSION['start_time']))
	{
		$elapsed_time = time() - $_SESSION['start_time'];
		if ($elapsed_time >= $timeout)
		{
			session_destroy();
			header("Location: login.php");
		}
	}
	$_SESSION['start_time'] = time();
?>