<?php
	require("Login_Check.php");
	if($_SESSION['User_Role'] != 'Admin')
		header("Location:Login.php");
	include("includes/db_connection.php");
	if(isset($_GET['i']))
	{
		$ID = $_GET['i'];
	}
	$sql = "SELECT * FROM tblsubjects WHERE ID='$ID'";
	$result = mysql_query($sql);
	if($row = mysql_fetch_array($result))
	{
		$Subject_Title = $row['Subject_Title'];
		$Course_Code = $row['Course_Code'];
	}
?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Edit Course</title>
		<?php
			require("includes/meta.php");
		?>
	</head>
	<body>

	<?php
		require("includes/Header.php");
	?>

	<section id="content">
	  <div class="container">
		<div class="row">
		  
		  <div class="grid_5">
		  <div class="grid_12">
			<h3 class="head__1">Edit Course <span style="font-size: 18px; float: right"><a href="ManageCoursesAdmin.php">Back to Courses</a></span></h3>
			<div class="fwn">
			  <p>Kindly fill out the following form to edit the Course details.</p>
			  <p>If you have problems with updation, you can <a href="contacts.php" rel="nofollow" class="color1">Click here</a> to contact us.</p>
			</div>
				  <form id="contact-form" method="POST" enctype="multipart/form-data">
					  <div class="contact-form-loader"></div>
					  <fieldset>
						<p>Fill the Following information to edit course.</p>
						<label class="phone">
						  <input type="text" class="required" name="Subject_Title" placeholder="Course Title" value="<?php echo $Subject_Title;?>" />
						</label>
						
						<label class="name">
						  <input type="text" class="required" name="Course_Code" placeholder="Course Code" value="<?php echo $Course_Code;?>"/>
						</label>
						
						<div class="clear"></div>
						<div>
							
						  <input type="submit" class="btn" name="Update" onclick="return ValidateForm();" value="Update Course" style="float: left; cursor:pointer;">
						</div>
					  </fieldset> 
					</form>   
		  </div>
		</div>
	  </div>
	</section>

	<?php
		require("includes/footer.php");
	?>

	<a href="#" id="toTop" class="fa fa-chevron-up"></a>
	</body>
</html>

<?php
	if(isset($_POST['Update']))
	{
		$Subject_Title = $_POST['Subject_Title'];
		$Course_Code = $_POST['Course_Code'];

		$query = "UPDATE tblsubjects SET Subject_Title='$Subject_Title', Course_Code='$Course_Code' WHERE ID='$ID'";
		$status = mysql_query($query);
		if($status)
			echo "<script>showSuccessMessage('Course Successfully Edited!')</script>";
		else
			echo "<script>showErrorMessage('Course is not Successfully Edited!')</script>";
	}
?>