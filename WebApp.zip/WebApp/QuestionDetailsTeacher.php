<?php
	require("Login_Check.php");
	if($_SESSION['User_Role'] != 'Teacher')
		header("Location:Login.php");
	include("includes/db_connection.php");
	if(isset($_SESSION['User_ID']))
	{
		$User_ID = $_SESSION['User_ID'];
		$query = "SELECT  u.*, r.RoleTitle FROM tblusers u join tblroles r on u.Role = r.ID WHERE u.User_ID='$User_ID'";
		$status = mysql_query($query);
		IF($row = mysql_fetch_array($status))
		{
			$FirstName = $row['FirstName'];
			$LastName = $row['LastName'];
			$Username = $row['Username'];
			$RegNo = $row['RegNo'];
			$Email = $row['Email'];
			$ProfilePic = $row['ProfilePic'];
			$RoleTitle = $row['RoleTitle'];
		}
	}
	
?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>Manage Questions</title>

<?php
	require("includes/meta.php");
?>
<script>
	$(function(){
		var qId = getQueryString("qId");
		$.post("QuestionDetails.php", { qId: qId}, function (data) {
		   $('#questionAnswer').html(data).show();
		   $('#divQuestions').hide();
		   $("#taAddAnswer").change(function(){
			   $(this).attr("value", $(this).val());
		   });
		   $("#saveAnswerNew").click(function (e) {
				e.preventDefault();
				
				var q = $("#taAddAnswer").val();
				var quesID = $("#hiddenQId").val();
				q = q.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
				$.post("TNewAnswer.php", { quesID: quesID, q: q}, function (data) {
				   showSuccessMessage('Answer is added..');
				  setTimeout(function() { window.location.reload(); }, 1000);
				});
				
			});
		});
	});
</script>
</head>
<body>

<?php
	require("includes/Header.php");
?>

<section id="content"><div class="ic"></div>
  <div class="container">
    <div class="row">
      <div class="grid_12">
        <h3 style="line-height: 0px; margin-bottom: 40px;">Teacher Profile</h3>
        <div style="width: 25%; float: left;">
		<img src="images/userPicture/<?php echo $ProfilePic;?>" style="height: 180px; margin-bottom: 20px;" alt="" class="img_inner fleft">
		<table style="width:100%">
				<tr>
					<td><p class="fwn">Registration No: <strong><?php echo $RegNo;?></strong></p></td>
				</tr>
				<tr>
					<td><p class="fwn">Username: <strong><?php echo $Username;?></strong></p></td>
				</tr>
				<tr>
					<td><p class="fwn">Email: <strong><?php echo $Email;?></strong></p></td>
				</tr>
				<tr>
					<td><p class="fwn"><a href="editProfileTeacher.php">Edit Profile</p></td>
				</tr>
				<tr>
					<td><p class="fwn"><a href="ChangePasswordTeacher.php">Change Password</p></td>
				</tr>
				<tr>
					<td><p class="fwn"><a href="ChangeProfileTeacher.php">Change Profile Picture</p></td>
				</tr>
			</table>
			</div>
        <div class="extra_wrapper"  style="width: 70%; float: right;">
          <blockquote class="bq1" style="padding-bottom: 60px;">
            <h3 style="padding-top: 0px; margin-bottom: -20px;">Manage Questions <span style="font-size: 18px; float: right"><a href="ManageQuestions.php">Back to Questions</a></span></h3>
			<div id="questionAnswer">
			</div>
		</blockquote>
        </div>
      </div>
    </div>
  </div>
</section>

<?php
	require("includes/footer.php");
?>

<a href="#" id="toTop" class="fa fa-chevron-up"></a>
</body>
</html>
