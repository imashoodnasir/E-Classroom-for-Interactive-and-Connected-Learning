<?php
	require("Login_Check.php");
	include("includes/db_connection.php");
	if(isset($_SESSION['User_ID']))
	{
		$User_ID = $_SESSION['User_ID'];
		$query = "SELECT * FROM tblusers WHERE User_ID='$User_ID'";
		$status = mysql_query($query);
		IF($row = mysql_fetch_array($status))
		{
			$FirstName = $row['FirstName'];
			$LastName = $row['LastName'];
			$RegNo = $row['RegNo'];
			$DOB = $row['DOB'];
			$Username = $row['Username'];
			$Email = $row['Email'];
			$Phone = $row['Phone'];
		}
	}
?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Edit Profile</title>
		<?php
			require("includes/meta.php");
		?>
	<script>
		$(function(){
			if(getQueryString('s')== '1')
				showSuccessMessage('Profile Saved');
			else if(getQueryString('s')== '0')
				showErrorMessage('Profile is not Saved');
		});
	</script>
	</head>
	<body>

	<?php
		require("includes/Header.php");
	?>

	<section id="content">
	  <div class="container">
		<div class="row">
		  
		  <div class="grid_5">
		  <div class="grid_12">
			<h3 class="head__1">Edit Profile <span style="font-size: 18px; float: right"><a href="ProfileStudent.php">Back to Profile</a></span></h3>
			<div class="fwn">
			  <p>Kindly fill out the following form to Update your profile.</p>
			  <p>If you have problems with updation, you can <a href="contacts.php" rel="nofollow" class="color1">Click here</a> to contact us.</p>
			</div>
				  <form id="contact-form" method="POST" enctype="multipart/form-data">
					  <div class="contact-form-loader"></div>
					  <fieldset>
						<p>Update the information of your profile.</p>
						<label class="name">
						  <input type="text" class="required" name="FirstName" placeholder="First Name:" value="<?php echo $FirstName;?>"/>
						</label>
					   
						<label class="email">
						  <input type="text" class="required" name="LastName" placeholder="Last Name:" value="<?php echo $LastName;?>"/>
						</label>
						<label class="phone">
						  <input type="text" class="required" name="RegNo" disabled placeholder="Registration No:" value="<?php echo $RegNo;?>" />
						</label>
						
						<label class="name" style="margin-left: 0px">
						  <input type="text" class="required" name="Username" placeholder="Username" value="<?php echo $Username;?>"/>
						</label>
						
						<label class="name"">
						  <input type="date" class="required" name="DOB" placeholder="Date of Birth:" value="<?php echo $DOB;?>" />
						</label>
						
						
						<label class="name">
						  <input type="email" class="required" name="Email" disabled placeholder="Email:" value="<?php echo $Email;?>" />
						</label>
						
						<label class="name"  style="margin-left: 0px">
						  <input type="text" class="required" name="Phone" placeholder="Phone:" onkeypress="return ValidateOnlyNumber(event);" value="<?php echo $Phone;?>" />
						</label>
						
						<div class="clear"></div>
						<div>
							
						  <input type="submit" class="btn" name="Update" onclick="return ValidateForm();" value="Update" style="float: left; cursor:pointer;">
						</div>
					  </fieldset> 
					</form>   
		  </div>
		</div>
	  </div>
	</section>

	<?php
		require("includes/footer.php");
	?>

	<a href="#" id="toTop" class="fa fa-chevron-up"></a>
	</body>
</html>

<?php
	if(isset($_POST['Update']))
	{
		//Owner Data
		$FirstName = $_POST['FirstName'];
		$LastName = $_POST['LastName'];
		$Username = $_POST['Username'];
		$DOB = $_POST['DOB'];
		$Phone = $_POST['Phone'];

		$query = "UPDATE tblusers SET FirstName='$FirstName', LastName='$LastName', Username='$Username', DOB='$DOB', Phone='$Phone' WHERE User_ID='$User_ID'";
		$status = mysql_query($query);
		$_SESSION['Name'] = "$FirstName $LastName";
		if($status)
			echo "<script>showSuccessMessage('Profile Successfully Edited!')</script>";
		else
			echo "<script>showErrorMessage('Profile is not Successfully Edited!')</script>";
	}
?>