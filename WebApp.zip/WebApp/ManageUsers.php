<?php
	require("Login_Check.php");
	if($_SESSION['User_Role'] != 'Admin')
		header("Location:Login.php");
	include("includes/db_connection.php");
	if(isset($_SESSION['User_ID']))
	{
		$User_ID = $_SESSION['User_ID'];
		$query = "SELECT  u.*, r.RoleTitle FROM tblusers u join tblroles r on u.Role = r.ID WHERE u.User_ID='$User_ID'";
		$status = mysql_query($query);
		IF($row = mysql_fetch_array($status))
		{
			$FirstName = $row['FirstName'];
			$LastName = $row['LastName'];
			$Username = $row['Username'];
			$RegNo = $row['RegNo'];
			$Email = $row['Email'];
			$ProfilePic = $row['ProfilePic'];
			$RoleTitle = $row['RoleTitle'];
		}
	}
	
?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>Manage Users</title>

<?php
	require("includes/meta.php");
?>

</head>
<body>

<?php
	require("includes/Header.php");
?>

<section id="content"><div class="ic"></div>
  <div class="container">
    <div class="row">
      <div class="grid_12">
        <h3 style="line-height: 0px; margin-bottom: 40px;">Admin Profile</h3>
        <div style="width: 25%; float: left;">
		<img src="images/userPicture/<?php echo $ProfilePic;?>" style="height: 180px; margin-bottom: 20px;" alt="" class="img_inner fleft">
		<table style="width:100%">
				<tr>
					<td><p class="fwn">Registration No: <strong><?php echo $RegNo;?></strong></p></td>
				</tr>
				<tr>
					<td><p class="fwn">Username: <strong><?php echo $Username;?></strong></p></td>
				</tr>
				<tr>
					<td><p class="fwn">Email: <strong><?php echo $Email;?></strong></p></td>
				</tr>
								<tr>
					<td><p class="fwn"><a href="editProfileAdmin.php">Edit Profile</p></td>
				</tr>
				<tr>
					<td><p class="fwn"><a href="ChangePasswordAdmin.php">Change Password</p></td>
				</tr>
				<tr>
					<td><p class="fwn"><a href="ChangeProfileAdmin.php">Change Profile Picture</p></td>
				</tr>
			</table>
			</div>
        <div class="extra_wrapper"  style="width: 70%; float: right;">
          <blockquote class="bq1">
            <h3 style="padding-top: 0px; margin-bottom: -20px;">Manage Users <span style="font-size: 18px; float: right"><a href="ProfileAdmin.php">Back to Profile</a></span></h3>
			<a href="AddNewUser.php" class="btn" name="Upload" style="margin-bottom: 10px; cursor:pointer;">Add New User</a>
			<table width="100%" style="margin-top: 20px; border-collapse: initial; border-spacing: 3px;" border="1">
				<tr style="background-color: #00B1BA; color: white;">
					<th>No.</th>
					<th>Name</th>
					<th>Reg. No</th>
					<th>Role</th>
					<th>Email</th>
					<th>Accepted</th>
					<th>Blocked</th>
					<th colspan="3">Action</th>
				</tr>
				<?php
					$count= 0;
					$Query = "SELECT * FROM tblusers";
					$Status = mysql_query($Query);
					WHILE($Row = mysql_fetch_array($Status))
					{
						$User_ID = $Row['User_ID'];
						$FirstName = $Row['FirstName'];
						$LastName = $Row['LastName'];
						$RegNo = $Row['RegNo'];
						$Email = $Row['Email'];
						$Role = $Row['Role'];
						$isAccepted = $Row['isAccepted'];
						$isBlocked = $Row['isBlocked'];
						$SubjectQuery = "SELECT * FROM tblroles WHERE ID='$Role'";
						$SubjectStatus = mysql_query($SubjectQuery);
						IF($SubjectRow = mysql_fetch_array($SubjectStatus))
						{
							$RoleTitle = $SubjectRow['RoleTitle'];
						}
						$count++;
						if(($count%2) == 0)
							$class="even";
						else
							$class="odd";
						echo "<tr class='$class'>
								<td>$count</td>
								<td>$FirstName $LastName</td>
								<td>$RegNo</td>
								<td>$RoleTitle</td>
								<td>$Email</td>
								<td><a href='AcceptUser.php?i=$User_ID' onclick='return Commonconfig()'><u>$isAccepted</u></a></td>
								<td><a href='BlockUser.php?i=$User_ID' onclick='return Commonconfig()'><u>$isBlocked</u></a></td>
								<td><a href='DeleteUser.php?i=$User_ID' onclick='return deleletconfig()'><u>Delete</u></a></td>
								<td><a href='EditUser.php?i=$User_ID'><u>Edit</u></a></td>
								<td><a href='ResetUser.php?i=$User_ID' onclick='return Resetconfig()'><u>Reset</u></a></td>
							</tr>";
					}
				?>
			</table>
          </blockquote>
        </div>
      </div>
    </div>
  </div>
</section>

<?php
	require("includes/footer.php");
?>

<a href="#" id="toTop" class="fa fa-chevron-up"></a>
</body>
</html>

<?php
	if(isset($_POST['Upload']))
	{
		$FileName = $_POST['FileName'];
		$Subject_ID = $_POST['Subject'];
		if(isset($_FILES['DocumentFile']))
		{
			$random_key = substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 30);
			$DocumentFile = $_FILES['DocumentFile']['name'];
			$temp_name= $_FILES['DocumentFile']['tmp_name'];
			move_uploaded_file($temp_name, "User_Documents/$random_key$DocumentFile");
			$DocumentFile = "$random_key$DocumentFile";
			$offset=5*60*60;
			$dateFormat="d-m-Y H:i:s";
			$CurrentDateTime=gmdate($dateFormat, time()+$offset);
		}
		$query = "INSERT INTO tbllibrary (User_ID, Subject_ID, DocumentFile, DocumentName, UploadDate) VALUES ('$User_ID', '$Subject_ID', '$DocumentFile', '$FileName', '$CurrentDateTime')";
		$status = mysql_query($query);
		if($status)
		{
			echo "<meta http-equiv='refresh' content='0'>";
		}
	}
?>