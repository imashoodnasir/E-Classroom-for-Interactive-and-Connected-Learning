<?php
	require("CheckValidity.php");
?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Login</title>
		
		<?php
			require("includes/meta.php");
		?>

	</head>
<body>

<?php
	require("includes/Header.php");
?>

<section id="content">
  <div class="container">
    <div class="row">
      
      <div class="grid_5">
      <div class="grid_12">
        <h3 class="head__1">Login Form</h3>
        <div class="fwn">
          <p>Kindly provide username and password to access your account.</p>
          <p>If you have problems with login, you can <a href="contacts.php" rel="nofollow" class="color1">Click here</a> to contact us.</p>
        </div>
              <form id="contact-form" method="POST">
                  <div class="contact-form-loader"></div>
                  <fieldset>
                    <label class="name">
                      <input type="text" class="required" name="Username" placeholder="Username:" value=""/>
                    </label><br/><br/><br/>

					<label class="name">
                      <input type="password" class="required" name="Password" placeholder="Password:" value=""/>
                    </label><br/><br/>
                   <label class="name" style="margin-left: -9%;">
                      <a href="ForgetPassword.php">Forget Password?</a>
                    </label>
                   
                  </fieldset> 
				  <input type="submit" class="btn" value="Login" onclick="return ValidateForm();" style="float: left; cursor:pointer; margin-top: -21px;">
                </form>   
      </div>
    </div>
  </div>
</section>

<?php
	require("includes/footer.php");
?>

<a href="#" id="toTop" class="fa fa-chevron-up"></a>
</body>
</html>