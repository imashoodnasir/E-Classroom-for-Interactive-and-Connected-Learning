<?php 
	require("Login_Check.php");
	if(isset($_REQUEST["quesID"]))
		$quesID = $_REQUEST["quesID"];
	if(isset($_REQUEST["q"]))
		$q = $_REQUEST["q"];
	if(isset($_SESSION['User_ID']))
		$User_ID = $_SESSION['User_ID'];
	include("includes/db_connection.php");
	$offset=5*60*60;
	$dateFormat="d-m-Y H:i:s";
	$CurrentDateTime=gmdate($dateFormat, time()+$offset);
	$query = "INSERT INTO `tblanswers`(`QuestionId`, `Answer`, `IsApproved`, `UserId`, `AnswerDate`) VALUES ('$quesID ', '$q', 'No', '$User_ID', '$CurrentDateTime')";
	$status = mysql_query($query);
?>