<?php
	require("Login_CheckUser.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>Contacts</title>
<?php require('Includes/meta.php');?>
</head>
<body>
<?php require('Includes/Header.php');?>
<header style="z-index: -100;">
  
</header>

<section id="content">
  <div class="container">
    <div class="row">
      <div class="grid_5">
        <h3 class="head__1">Address:</h3>
        <address class="text3">
          Ghulam Haider Plaza <br>Car Chok <br>Rawalpindi
        </address>
      </div>
      <div class="grid_4">
        <h3 class="head__1">Phone:</h3>
        <div class="text3">
          +92 51 8737 839 <br>+92 51 8737 840
        </div>
      </div>
      <div class="grid_3">
        <h3 class="head__1">E-mail:</h3>
        <div class="text3">
          info@eclassroom.com<br>
        </div>
      </div>
      <div class="grid_12">
              <form id="contact-form" method="POST">
                  <div class="contact-form-loader"></div>
                  <fieldset>
                    <label class="name">
                      <input type="text" name="name" placeholder="Name:" value="" required/>
                    </label>
                   
                    <label class="email">
						<?php
							if(isset($_SESSION['Email']))
							{
								$Email = $_SESSION['Email'];
								echo "<input type='text' name='email' disabled value='$Email'/>";
							}
							else
							{
								echo "<input type='text' name='email' required value='' placeholder='Email:' />";
							}
						?>
                      
                    </label>
                    <label class="phone">
                      <input type="text" name="phone" placeholder="Phone:" value=""/>
                    </label>
                   
                    <label class="message">
                      <textarea name="message" placeholder="Message:" required></textarea>
                    </label>
                    <div class="clear"></div>
                    <div>
                      <input type="submit" name="SendEmail" value="Send e-mail" class="btn"/>
                    </div>
                  </fieldset>
                </form>   
      </div>
    </div>
  </div>
</section>
<?php require('Includes/Footer.php');?>
</body>
</html>

<?php
	if(isset($_POST['SendEmail']))
	{
		$name = $_POST['name'];
		$phone = $_POST['phone'];
		$email = $_POST['email'];
		$message = $_POST['message'];
		session_start();
		$_SESSION['from'] = 'inzamamgee@gmail.com';
		$_SESSION['to'] = $email;
		$_SESSION['subject'] = 'Thank You for Contacting E-Classroom';
		$_SESSION['body'] = "Hello $name,\n\nYour Complaint is successfully received and we will get back to you on this as soon as possible.\n";
		$_SESSION['body'] .= "Once we Reviewed the issue, we will solve that as soon as possible.\n";
		$_SESSION['body'] .= "Thank you for your patience and Thank you for contacting us.\n\n";
		$_SESSION['body'] .= "Regards:\n";
		$_SESSION['body'] .= "Team E-Classroom.";
		require_once "SendMail.php";
	}
?>