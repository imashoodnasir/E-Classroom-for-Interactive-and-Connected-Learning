<?php
	session_start();
	if(isset($_SESSION['Username']) && isset($_SESSION['Password']))
	{
		$Username = $_SESSION['Username'];
		$Password = $_SESSION['Password'];
	}
	
	require("includes/db_connection.php");
	$query = mysql_query("SELECT * FROM tblusers WHERE Username='$Username' AND BINARY Password='$Password' AND isAccepted='Yes' AND isBlocked='No'");
	$row = mysql_fetch_array($query);
	if(is_array($row)) 
	{
		$User_ID = $row['User_ID'];
		$FirstName = $row['FirstName'];
		$Username = $row['Username'];
		$LastName = $row['LastName'];
		$Role = $row['Role'];
		$CurrentLoginTime = $row['CurrentLoginTime'];
		$LoginCounts = $row['LoginCounts'];
		$_SESSION['Name'] = $Username;
		$_SESSION['user_name'] = $Username;
		$_SESSION['Email'] = $row['Email'];
		$_SESSION['ProfilePic'] = $row['ProfilePic'];
		$_SESSION['User_ID'] = $User_ID;
		$_SESSION['Role'] = $Role;
		$LoginCounts++;
		$time = date('m/d/Y h:i:s a', time());
		$query = "UPDATE tblusers SET LastLogin='$CurrentLoginTime', CurrentLoginTime='$time', LoginCounts='$LoginCounts' WHERE User_ID='$User_ID'";
		$status = mysql_query($query);
		if($Role == '1')
		{
			header("Location:ProfileAdmin.php");
			$_SESSION['User_Role'] = "Admin";
		}
		else if($Role == '2')
		{
			header("Location:ProfileTeacher.php");
			$_SESSION['User_Role'] = "Teacher";
		}
		else if($Role == '3')
		{
			header("Location:ProfileStudent.php");
			$_SESSION['User_Role'] = "Student";
		}
		else
		{
			header("Location:Login.php");
		}
		
	}
	else
	{
		header("Location:Login.php");
	}
?>