<?php
	if(isset($_GET['i']))
	{
		$ID = $_GET['i'];
	}
	include("includes/db_connection.php");
	$sql = "SELECT DocumentFile FROM tbllibrary WHERE ID='$ID'";
	$result = mysql_query($sql);
	if($row = mysql_fetch_array($result))
	{
		$DocumentFile = $row['DocumentFile'];
	}
	unlink("User_Documents/".$DocumentFile);
	$sql = "Delete FROM tbllibrary WHERE ID='$ID'";
	$result = mysql_query($sql);
	header('Location: ' . $_SERVER['HTTP_REFERER']);
?>
