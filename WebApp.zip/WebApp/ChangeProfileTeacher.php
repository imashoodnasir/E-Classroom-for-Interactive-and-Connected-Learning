<?php
	require("Login_Check.php");
	if($_SESSION['User_Role'] != 'Teacher')
		header("Location:Login.php");
	include("includes/db_connection.php");
	if(isset($_SESSION['User_ID']))
	{
		$User_ID = $_SESSION['User_ID'];
	}
?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Change Profile Picture</title>
		<?php
			require("includes/meta.php");
		?>

	</head>
	<body>

	<?php
		require("includes/Header.php");
	?>

	<section id="content">
	  <div class="container">
		<div class="row">
		  
		  <div class="grid_5">
		  <div class="grid_12">
			<h3 class="head__1">Change Profile Picture<span style="float: right; font-size: 24px;"><a href="ProfileTeacher.php">Back</a></span></h3>
			<div class="fwn">
			  <p>Kindly select your picture Update your profile.</p>
			  <p>If you have problems with updation, you can <a href="contacts.php" rel="nofollow" class="color1">Click here</a> to contact us.</p>
			</div>
				  <form id="contact-form" method="POST" enctype="multipart/form-data">
					  <div class="contact-form-loader"></div>
					  <fieldset>
						<label class="name" style="margin-left: 0px; margin-right: 760px;">
						  Select Profile Picture: <input type="file" class="btnfile" required name="ProfilePicture" style=" width: 336px; margin-bottom: 30px;"/>
						</label>
						
						<div class="clear"></div>
						<div>
							
						  <input type="submit" name="Update" class="btn" value="Update" style="float: left; cursor:pointer;">
						</div>
					  </fieldset> 
					</form>   
		  </div>
		</div>
	  </div>
	</section>

	<?php
		require("includes/footer.php");
	?>

	<a href="#" id="toTop" class="fa fa-chevron-up"></a>
	</body>
</html>

<?php
	include("includes/db_connection.php");
	if(isset($_POST['Update']))
	{
		if(isset($_FILES['ProfilePicture']))
		{
			$random_key = substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 30);
			$ProfilePicture = $_FILES['ProfilePicture']['name'];
			$temp_name= $_FILES['ProfilePicture']['tmp_name'];
			move_uploaded_file($temp_name, "images/userPicture/$random_key$ProfilePicture");
			$ProfilePicture = "$random_key$ProfilePicture";
			$query = "UPDATE tblusers SET ProfilePic='$ProfilePicture' WHERE User_ID='$User_ID'";
			$status = mysql_query($query);
			$_SESSION['ProfilePic'] = $ProfilePicture;
			if($status)
				echo "<script>showSuccessMessage('Profile Picture Successfully Changed!')</script>";
			else
				echo "<script>showErrorMessage('Error in Changing Profile Picture!')</script>";
		}
	}
?>