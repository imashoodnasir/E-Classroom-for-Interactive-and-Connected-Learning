<?php
	require("Login_Check.php");
	if($_SESSION['User_Role'] != 'Admin')
		header("Location:Login.php");
	if(isset($_GET['i']))
	{
		$User_ID = $_GET['i'];
	}
	include("includes/db_connection.php");
	$sql = "SELECT isBlocked FROM tblusers WHERE User_ID='$User_ID'";
	$result = mysql_query($sql);
	if($row = mysql_fetch_array($result))
	{
		$isBlocked = $row['isBlocked'];
	}
	$query = "";
	if($isBlocked == "Yes")
		$query = "UPDATE tblusers SET isBlocked='No' WHERE User_ID='$User_ID'";
	else if($isBlocked == "No")
		$query = "UPDATE tblusers SET isBlocked='Yes' WHERE User_ID='$User_ID'";
	$result = mysql_query($query);
	header('Location: ' . $_SERVER['HTTP_REFERER']);
?>
