$(function(){
// IPad/IPhone
  var viewportmeta = document.querySelector && document.querySelector('meta[name="viewport"]'),
  ua = navigator.userAgent,

  gestureStart = function () {viewportmeta.content = "width=device-width, minimum-scale=0.25, maximum-scale=1.6";},

  scaleFix = function () {
    if (viewportmeta && /iPhone|iPad/.test(ua) && !/Opera Mini/.test(ua)) {
      viewportmeta.content = "width=device-width, minimum-scale=1.0, maximum-scale=1.0";
      document.addEventListener("gesturestart", gestureStart, false);
    }
  };
  
  scaleFix();
  // Menu Android
  if(window.orientation!=undefined){
  var regM = /ipod|ipad|iphone/gi,
   result = ua.match(regM)
  if(!result) {
   $('.sf-menu li').each(function(){
    if($(">ul", this)[0]){
     $(">a", this).toggle(
      function(){
       return false;
      },
      function(){
       window.location.href = $(this).attr("href");
      }
     );
    } 
   })
  }
 }
});
var ua=navigator.userAgent.toLocaleLowerCase(),
 regV = /ipod|ipad|iphone/gi,
 result = ua.match(regV),
 userScale="";
if(!result){
 userScale=",user-scalable=0"
}
document.write('<meta name="viewport" content="width=device-width,initial-scale=1.0'+userScale+'">')

var currentYear = (new Date).getFullYear();
  $(document).ready(function() {
  $("#copyright-year").text( (new Date).getFullYear() );
  });

  $(function(){
  $('.sf-menu').superfish({autoArrows: true})
})

function getQueryString(qString) {
    var queryString = decodeURI(location.search);
    if (queryString.length == 0)
        return;
    queryString = queryString.substr(1);

    var qPair = queryString.split("&");

    for (var i = 0; i < qPair.length; i++) {
        var pair = qPair[i].split("=");
        if (pair[0] == qString)
            return pair[1];
    }
}

// DEVICE.JS AND SMOOTH SCROLLIG

function include(url){document.write('<script type="text/javascript" src="'+url+'"></script>')}
include('js/device.js');
include('js/jquery.mousewheel.js');
include('js/jquery.simplr.smoothscroll.js');

  $(function () { 
    if ($('html').hasClass('desktop')) {
        $.srSmoothscroll();
    }
  });

function isPasswordEqual() {
	var password = $(".validatePassword").first();
	var confirmPassword = $(".validatePassword").last();
	if (password.val() != confirmPassword.val()) {
		$(".validatePassword").addClass("error");
		flag = false;
	}
	//else{
		//$(".validatePassword").removeClass('error');
	//}
	return flag;
}

function ValidateOnlyNumber(evt) {
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57))
        return false;
    return true;
}

function ValidateForm() {
    var flag = true;
    $(".required").removeClass("error");
    $(".required").each(function () {
        if (($.trim($(this).val()) == "" || $(this).val() == 0) && $(this).attr("disabled") != "disabled" || $.trim($(this).val()) == "__:__" || $.trim($(this).val()) == "__/__/____") {
            if (!$(this).hasClass("error"))
                $(this).addClass("error");
            flag = false;
        }
		else{
			$(this).removeClass("error");
		}
    });
	if(window.location.href.indexOf("EditNotes.php") > -1 || window.location.href.indexOf("UploadNotesNew.php")> -1){
		var body = tinyMCE.get('elm1').getContent();
		body = encodeURI(body);
		$('#hdnDescription').val(body);
	}
    return flag;
}

function deleletconfig(){
	var del=window.confirm("Are you sure you want to delete this record?");
	return del;
}

function Commonconfig(){
	var del=window.confirm("Are you sure you want to do this?");
	return del;
}

function Resetconfig(){
	var del=window.confirm("Are you sure you want to reset the password?");
	return del;
}

function Acceptconfig(){
	var del=window.confirm("Are you sure you want to Accept this?");
	return del;
}

function Rejectconfig(){
	var rej=window.confirm("Are you sure you want to Reject this?");
	return rej;
}

function DeleteAnswer(){
	var rej=window.confirm("Are you sure you want to Delete this Answer?");
	return rej;
}
function CreateEditor(content) {

    tinyMCE.init({
        //mode: "textareas",
        mode: "none",
        theme: "advanced",
        theme_advanced_buttons1: "bold,italic,underline,strikethrough,|,bullist,numlist,|,justifyleft,justifycenter,justifyright,justifyfull,formatselect,fontselect,fontsizeselect,|,forecolor,backcolor",
        theme_advanced_toolbar_location: "top",
        theme_advanced_toolbar_align: "left",
        theme_advanced_statusbar_location: "bottom",
        theme_advanced_resizing: false
    });

    tinyMCE.execCommand('mceAddControl', false, 'elm1');
    LoadEditorValue();
}

function RemoveTinyMCE() {
    if (tinyMCE.getInstanceById('elm1')) {
        tinyMCE.execCommand('mceFocus', false, 'elm1');
        tinyMCE.execCommand('mceRemoveControl', false, 'elm1');
    }
}
function LoadEditorValue() {
    var Description = decodeURI($("[id$='hdnDescription']").val());
    $("#elm1").val(Description);
}
