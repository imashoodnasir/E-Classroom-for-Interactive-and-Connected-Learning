<?php
	require("Login_CheckUser.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Statement of E-Classroom</title>

<?php
	require("includes/meta.php");
?>

</head>
<body>

<?php
	require("includes/Header.php");
?>

<section id="content">

  <div class="container">
    <div class="row">
      <div class="grid_12">
        <h3>Statement of E-Classroom</h3>
        <div class="extra_wrapper">
          <p style="text-align: justify">
This Statement of Rights and Responsibilities ("Statement," "Terms," or "SRR") derives from theE-Classroom Principles, and is our terms of service that governs our relationship with company s and others who interact with E-Classroom, as well as World Trade Link (wtradelink) brands, products and services, which we call the “E-Classroom Services” or “Services”. By using or accessing the E-Classroom Services, you agree to this Statement, as updated from time to time in accordance with Section 13 below. Additionally, you will find resources at the end of this document that help you understand how E-Classroom works.
Because E-Classroom provides a wide range of Services, we may ask you to review and accept supplemental terms that apply to your interaction with a specific app, product, or service. To the extent those supplemental terms conflict with this SRR, the supplemental terms associated with the app, product, or service govern with respect to your use of such app, product or service to the extent of the conflict.
Privacy

your privacy is very important to us. We designed our Data Policy to make important disclosures about how you can use World Trade Link (wtradelink) to share with others and how we collect and can use your content and information. We encourage you to read the Data Policy, and to use it to help you make informed decisions. 
 
Sharing Your Information

You own all of the content and information you post on World Trade Link (wtradelink), and you can control how it is shared through your privacy and application settings. In addition:
1.	For content that is covered by intellectual property rights, like photos and videos (IP content), you specifically give us the following permission, subject to your privacy and application settings: you grant us a non-exclusive, transferable, sub-licensable, royalty-free, worldwide license to use any IP content that you post on or in connection with World Trade Link (wtradelink) (IP License). This IP License ends when you delete your IP content or your account unless your content has been shared with others, and they have not deleted it.
2.	When you delete IP content, it is deleted in a manner similar to emptying the recycle bin on a computer. However, you understand that removed content may persist in backup copies for a reasonable period of time (but will not be available to others).
3.	When you use an application, the application may ask for your permission to access your content and information as well as content and information that others have shared with you.  We require applications to respect your privacy, and your agreement with that application will control how the application can use, store, and transfer that content and information.  (To learn more about Platform, including how you can control what information other people may share with applications, read our Data Policy and Platform Page.)
4.	When you publish content or information using the Public setting, it means that you are allowing everyone, including people off of World Trade Link (wtradelink), to access and use that information, and to associate it with you (i.e., your name and profile picture).
5.	We always appreciate your feedback or other suggestions about World Trade Link (wtradelink), but you understand that we may use your feedback or suggestions without any obligation to compensate you for them (just as you have no obligation to offer them).
 
Safety usages 

We do our best to keep World Trade Link (wtradelink) safe, but we cannot guarantee it. We need your help to keep World Trade Link (wtradelink) safe, which includes the following commitments by you:
6.	You will not post unauthorized commercial communications (such as spam) on World Trade Link (wtradelink).
7.	You will not collect users' content or information, or otherwise access World Trade Link (wtradelink), using automated means (such as harvesting bots, robots, spiders, or scrapers) without our prior permission.
8.	You will not engage in unlawful multi-level marketing, such as a pyramid scheme, on World Trade Link (wtradelink).
9.	You will not upload viruses or other malicious code.
10.	You will not solicit login information or access an account belonging to someone else.
11.	You will not bully, intimidate, or harass any user.
12.	You will not post content that: is hate speech, threatening, or pornographic; incites violence; or contains nudity or graphic or gratuitous violence.
13.	You will not develop or operate a third-party application containing alcohol-related, dating or other mature content (including advertisements) without appropriate age-based restrictions.
14.	You will not use World Trade Link (wtradelink) to do anything unlawful, misleading, malicious, or discriminatory.
15.	You will not do anything that could disable, overburden, or impair the proper working or appearance of World Trade Link (wtradelink), such as a denial of service attack or interference with page rendering or other World Trade Link (wtradelink) functionality.
16.	You will not facilitate or encourage any violations of this Statement or our policies.
 
Sign up and Account Security

World Trade Link (wtradelink) users provide their real names and information, and we need your help to keep it that way. Here are some commitments you make to us relating to registering and maintaining the security of your account:
17.	You will not provide any false personal information on World Trade Link (wtradelink), or create an account for anyone other than yourself without permission.
18.	You will not create more than one personal account.
19.	If we disable your account, you will not create another one without our permission.
20.	You will not use your personal timeline primarily for your own commercial gain, and will use a World Trade Link (wtradelink) Page for such purposes.
21.	You will not use World Trade Link (wtradelink) if you are under 13.
22.	You will not use World Trade Link (wtradelink) if you are a convicted sex offender.
23.	You will keep your contact information accurate and up-to-date.
24.	You will not share your password (or in the case of developers, your secret key), let anyone else access your account, or do anything else that might jeopardize the security of your account.
25.	You will not transfer your account (including any Page or application you administer) to anyone without first getting our written permission.
26.	If you select a username or similar identifier for your account or Page, we reserve the right to remove or reclaim it if we believe it is appropriate (such as when a trademark owner complains about a username that does not closely relate to a user's actual name).
 
Protecting Other People's Rights

We respect other people's rights, and expect you to do the same.
27.	You will not post content or take any action on World Trade Link (wtradelink) that infringes or violates someone else's rights or otherwise violates the law.
28.	We can remove any content or information you post on World Trade Link (wtradelink) if we believe that it violates this Statement or our policies.
29.	We provide you with tools to help you protect your intellectual property rights. To learn more, visit our How to Report Claims of Intellectual Property Infringement page.
30.	If we remove your content for infringing someone else's copyright, and you believe we removed it by mistake, we will provide you with an opportunity to appeal.
31.	If you repeatedly infringe other people's intellectual property rights, we will disable your account when appropriate.
32.	You will not use our copyrights or Trademarks or any confusingly similar marks, except as expressly permitted by our Brand Usage Guidelines or with our prior written permission.
33.	If you collect information from users, you will: obtain their consent, make it clear you (and not World Trade Link (wtradelink)) are the one collecting their information, and post a privacy policy explaining what information you collect and how you will use it.
34.	You will not post anyone's identification documents or sensitive financial information on World Trade Link (wtradelink).
35.	You will not tag users or send email invitations to non-users without their consent. World Trade Link (wtradelink) offers social reporting tools to enable users to provide feedback about tagging.
 

 
Payments

If you make a payment on World Trade Link (wtradelink), you agree to our Payments Terms unless it is stated that other terms apply.
 
Special Provisions Applicable to Developers/Operators of Applications and Websites 

If you are a developer or operator of a Platform application or website or if you use Social Plugins, you must comply with the World Trade Link (wtradelink) Platform Policy.
Amendments
36.	We’ll notify you before we make changes to these terms and give you the opportunity to review and comment on the revised terms before continuing to use our Services.
37.	If we make changes to policies, guidelines or other terms referenced in or incorporated by this Statement, we may provide notice on the Site Governance Page.
38.	Your continued use of the World Trade Link (wtradelink) Services, following notice of the changes to our terms, policies or guidelines, constitutes your acceptance of our amended terms, policies or guidelines.
 
Termination

If you violate the letter or spirit of this Statement, or otherwise create risk or possible legal exposure for us, we can stop providing all or part of World Trade Link (wtradelink) to you. We will notify you by email or at the next time you attempt to access your account. You may also delete your account or disable your application at any time. 
 
Disputes
39.	You will resolve any claim, cause of action or dispute (claim) you have with us arising out of or relating to this Statement or World Trade Link (wtradelink).
 
Other
40.	If you are a resident of or have your principal place of business in the US or Canada, this Statement is an agreement between you and World Trade Link (wtradelink), Inc.  Otherwise, this Statement is an agreement between you and World Trade Link (wtradelink) Ireland Limited.  References to “us,” “we,” and “our” mean World Trade Link (wtradelink), Inc. or World Trade Link (wtradelink) Ireland Limited, as appropriate.
41.	This Statement makes up the entire agreement between the parties regarding World Trade Link (wtradelink), and supersedes any prior agreements.
42.	If any portion of this Statement is found to be unenforceable, the remaining portion will remain in full force and effect.
43.	If we fail to enforce any of this Statement, it will not be considered a waiver.
44.	Any amendment to or waiver of this Statement must be made in writing and signed by us.
45.	You will not transfer any of your rights or obligations under this Statement to anyone else without our consent.
46.	All of our rights and obligations under this Statement are freely assignable by us in connection with a merger, acquisition, or sale of assets, or by operation of law or otherwise.
47.	Nothing in this Statement shall prevent us from complying with the law.
48.	This Statement does not confer any third party beneficiary rights.
49.	We reserve all rights not expressly granted to you.
50.	You will comply with all applicable laws when using or accessing World Trade Link (wtradelink).
          </p>
        </div>
      </div>
    </div>
  </div>
</section>

<?php
	require("includes/footer.php");
?>

<a href="#" id="toTop" class="fa fa-chevron-up"></a>
</body>
</html>