<?php
	require("Login_Check.php");
	if($_SESSION['User_Role'] != 'Admin')
		header("Location:Login.php");
	include("includes/db_connection.php");
	if(isset($_SESSION['User_ID']))
	{
		$User_ID = $_SESSION['User_ID'];
	}
?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Change Password</title>
		<?php
			require("includes/meta.php");
		?>

	</head>
	<body>

	<?php
		require("includes/Header.php");
	?>

	<section id="content">
	  <div class="container">
		<div class="row">
		  
		  <div class="grid_5">
		  <div class="grid_12">
			<h3 class="head__1">Change Password<span style="float: right; font-size: 24px;"><a href="ProfileAdmin.php">Back</a></span></h3>
			<div class="fwn">
			  <p>Kindly Change your password Using the following form.</p>
			  <p>If you have problems with updation, you can <a href="contacts.php" rel="nofollow" class="color1">Click here</a> to contact us.</p>
			</div>
				  <form id="contact-form" method="POST" enctype="multipart/form-data">
					  <div class="contact-form-loader"></div>
					  <fieldset>
						<label class="name">
						  <input type="password" name="oldPassword" placeholder="Old Password:"/>
						</label>
						
						<label class="name">
						  <input type="password" class="required validatePassword" name="Password" placeholder="New Password:"/>
						</label>
						
						<label class="name">
						  <input type="password" class="required validatePassword"  onBlur="isPasswordEqual()" name="ConfirmPassword" placeholder="Confirm Password:"/>
						</label>
						
						<div class="clear"></div>
						<div>
							
						  <input type="submit" name="Update" class="btn" onclick="return ValidateForm();" value="Update" style="float: left; cursor:pointer;">
						</div>
					  </fieldset> 
					</form>   
		  </div>
		</div>
	  </div>
	</section>

	<?php
		require("includes/footer.php");
	?>

	<a href="#" id="toTop" class="fa fa-chevron-up"></a>
	</body>
</html>

<?php
	include("includes/db_connection.php");
	if(isset($_POST['Update']))
	{
		$oldPassword = $_POST['oldPassword'];
		$checkQuery = "SELECT Password FROM tblusers WHERE  User_ID='$User_ID' AND Password='$oldPassword'";
		$checkStatus = mysql_query($checkQuery);
		if($rowStatus = mysql_fetch_array($checkStatus))
		{
			$Password = $rowStatus['Password'];
			if($oldPassword == $Password)
			{
				$Password = $_POST['Password'];
				$query = "UPDATE tblusers SET Password='$Password' WHERE User_ID='$User_ID'";
				$status = mysql_query($query);
				if($status)
					echo "<script>showSuccessMessage('Password Successfully Changed!')</script>";
				else
					echo "<script>showErrorMessage('Error in Changing Password!')</script>";
			}
		}
		else
			echo "<script>showErrorMessage('Old Password Mismatched!')</script>";
		
	}
?>