<?php
	require("Login_Check.php");
	if($_SESSION['User_Role'] != 'Teacher')
		header("Location:Login.php");
	if(isset($_GET['i']))
	{
		$User_ID = $_GET['i'];
	}
	if(isset($_GET['s']))
	{
		$Subject_ID = $_GET['s'];
	}
	include("includes/db_connection.php");
	$sql = "Delete FROM tblenrolledstudents WHERE User_ID='$User_ID' AND Subject_ID='$Subject_ID'";
	$result = mysql_query($sql);
	header('Location: ' . $_SERVER['HTTP_REFERER']);
?>
