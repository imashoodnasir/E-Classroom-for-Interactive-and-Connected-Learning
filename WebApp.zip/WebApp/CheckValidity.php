<?php
	session_start();
	if(isset($_POST['Username']) && isset($_POST['Password']))
	{
		$_SESSION['Username'] = $_POST['Username'];
		$_SESSION['Password'] = $_POST['Password'];
		require("LoginCheck.php");
	}
	else
	{
		session_destroy();
	}
?>