<?php
	require("Login_Check.php");
	include("includes/db_connection.php");
	if(isset($_SESSION['User_ID']))
	{
		$User_ID = $_SESSION['User_ID'];
		$query = "SELECT  u.*, r.RoleTitle FROM tblusers u join tblroles r on u.Role = r.ID WHERE u.User_ID='$User_ID'";
		$status = mysql_query($query);
		IF($row = mysql_fetch_array($status))
		{
			$FirstName = $row['FirstName'];
			$LastName = $row['LastName'];
			$Username = $row['Username'];
			$RegNo = $row['RegNo'];
			$Email = $row['Email'];
			$ProfilePic = $row['ProfilePic'];
			$RoleTitle = $row['RoleTitle'];
		}
	}
	
?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>Ask Questions</title>

<?php
	require("includes/meta.php");
?>
<script src="js/prefixfree.min.js"></script>
<style type="text/css">
        
    </style>
    <script type="text/javascript">
        var myVar = null
        $(function () {
			$("#btnSubmit").click(function (e) {
				e.preventDefault();
				var q = $("#textQuestion").val();
				var Subject = $("#Subject").val();
				q = q.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
				$.post("SQuestionHandler.php", { q: q, subject: Subject}, function (data) {
				   $('#lblClose').click();
				   showSuccessMessage('Question is Saved! And Waiting approval.');
				});
			});
			
            $("[id$='txtQuestion']").keyup(function (e) {
                $("#divQuestions").hide();
                var val = $(this).val().replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
                clearTimeout(myVar);
                if (val != "") {
                    myVar = setTimeout(function () {
                        $.post("QuestionHandler.php", { val: $.trim(val)}, function (data) {
                            $("#divQuestions").html(data).show();
                            clickQuestion();
                        });
                    }, 500);
                }
            });
            $("body").click(function (e) {
                var container = $("#divQuestions");
                var containertext = $("[id$='txtQuestion']");
                if (!container.is(e.target) && container.has(e.target).length === 0 && !containertext.is(e.target) && containertext.has(e.target).length === 0) {
                    container.hide();
                }
            });
        });
        
        function clickQuestion() {
            $(".divChatQuestion").click(function () {
                var qId = $(this).closest(".divChatMessage").find(".QuestionId").val();
                $.post("QuestionDetails.php", { qId: qId}, function (data) {
				   $('#questionAnswer').html(data).show();
				   $('#divQuestions').hide();
				   $("#taAddAnswer").change(function(){
					   $(this).attr("value", $(this).val());
				   });
				   $("#saveAnswerNew").click(function (e) {
						e.preventDefault();
						
						var q = $("#taAddAnswer").val();
						var quesID = $("#hiddenQId").val();
						q = q.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
						$.post("SNewAnswer.php", { quesID: quesID, q: q}, function (data) {
						   showSuccessMessage('Answer is waiting for Approval..');
						  
						});
						
					});
				});
            });
        }
    </script>
</head>
<body>

<?php
	require("includes/Header.php");
?>

<section id="content"><div class="ic"></div>
  <div class="container">
    <div class="row">
      <div class="grid_12">
        <h3 style="line-height: 0px; margin-bottom: 40px;">Ask Question <span style="font-size: 18px; float: right"><a href="ProfileStudent.php">Back to Profile</a></span></h3>
        <div style="width: 25%; float: left;">
		<img src="images/userPicture/<?php echo $ProfilePic;?>" style="height: 180px; margin-bottom: 20px;" alt="" class="img_inner fleft">
		<table style="width:100%">
				<tr>
					<td><p class="fwn">Registration No: <strong><?php echo $RegNo;?></strong></p></td>
				</tr>
				<tr>
					<td><p class="fwn">Username: <strong><?php echo $Username;?></strong></p></td>
				</tr>
				<tr>
					<td><p class="fwn">Email: <strong><?php echo $Email;?></strong></p></td>
				</tr>
				<tr>
					<td><p class="fwn"><a href="editProfile.php">Edit Profile</p></td>
				</tr>
				<tr>
					<td><p class="fwn"><a href="forgetPassword.php">Change Password</p></td>
				</tr>
			</table>
			</div>
        <div class="extra_wrapper"  style="width: 70%; float: right;">
          <blockquote class="bq1" style="min-height: 400px">
            <center><h3 style="padding-top: 0px; margin-bottom: -20px;">Write your Question</h3></center>
			<div style="position: relative; margin-top: 15px;">
				<center><input type="text" id="txtQuestion" class="style1" style="width: 87%; height: 39px; padding-right: 35px; font-size: 19px; padding-left: 10px;" autocomplete="off" /></center>
				<span style="position: absolute; right: 13.5%; top: 3px;">
				</span>
				<div id="divQuestions"></div>
			</div>
			<div id="questionAnswer" style="display:none;">
			</div>
          </blockquote>
        </div>
      </div>
    </div>
  </div>
</section>

<?php
	require("includes/footer.php");
?>
<input class="modal-state" id="modal-1" type="checkbox" />
    <div class="modal">
        <label class="modal__bg" for="modal-1"></label>
        <div class="modal__inner">
            <label id="lblClose" class="modal__close" for="modal-1"></label>
            <h2 style="line-height: 26px;background-color: #8AD1A8;padding: 8px;text-align: center;font-size: 21px !important;margin: -7px 9px;">
                New Question
            </h2>
            <p><br /></p>
            <p>
                 <table width="95%">
                        <tr>
                            <td>Question:
                            </td>
                            <td>
                                <textarea id="textQuestion" style="width:100%;height:200px; resize:none;"></textarea>
							</td>
                        </tr>
                        <tr>
                            <td></td>
                            <td>
								<select name="Subject" id="Subject" class="required">
								<option selected class="required" disabled>--SELECT Subject--</option>
								<?php
									include("includes/db_connection.php");
									$query = "SELECT * FROM tblsubjects WHERE isActive='Yes'";
									$status = mysql_query($query);
									WHILE($row = mysql_fetch_array($status))
									{
										$ID = $row['ID'];
										$Subject_Title = $row['Subject_Title'];
										echo "<option value='$ID'>$Subject_Title</option>";
									}
								?>
								</select>
							</td>
                        </tr>
						<tr>
                            <td></td>
                            <td>
                                <input type="button" class="btn" value="Add New Question" id="btnSubmit"  />
							</td>
                        </tr>
                    </table>
            </p>
            
        </div>
    </div>

       


</body>
</html>