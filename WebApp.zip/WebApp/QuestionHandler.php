<?php 
	require("Login_Check.php");
	if(isset($_REQUEST["val"]))
		$val = $_REQUEST["val"];
	if($val){ 
		echo "
		<div id='divNew' style='font-size: 18px; padding: 10px; text-align: center;height: 30px;'>
			<!--<a id='aAskNew' class='btn btn-info btn-lg' data-toggle='modal' data-target='#myModal'>Ask as New</a>-->
			<label for='modal-1' style='cursor:pointer;text-decoration:underline'>Ask as New</label>
		</div>";
		include("includes/db_connection.php");
		$query = "Select * from tblquestion where IsApproved = 'Yes' and Question like '%$val%' ";
		$status = mysql_query($query);
		WHILE($row = mysql_fetch_array($status))
		{
			$Question = $row['Question'];
			$ID = $row['ID'];
			echo "<div class='divChatMessage style2'>
					<div class='divChatQuestion'>
						<pre class='spnQuestion' >$Question</pre>
						<input type='hidden' class='QuestionId' value='$ID' />
					</div>
				</div>";
		}			 
	}
?>