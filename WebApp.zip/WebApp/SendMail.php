<?php
require_once "Mail.php";

if(isset($_SESSION['from']) && isset($_SESSION['to']) && isset($_SESSION['subject']) && isset($_SESSION['body']))
{
	$from = $_SESSION['from'];
	$to = $_SESSION['to'];
	$subject = $_SESSION['subject'];
	$body = $_SESSION['body'];
}
$headers = array(
    'From' => $from,
    'To' => $to,
    'Subject' => $subject
);

$smtp = Mail::factory('smtp', array(
        'host' => 'ssl://smtp.gmail.com',
        'port' => '465',
        'auth' => true,
        'username' => 'inzamamgee@gmail.com',
        'password' => '02104531methebest'
    ));

$mail = $smtp->send($to, $headers, $body);

if (PEAR::isError($mail)) 
{
    echo('<p>' . $mail->getMessage() . '</p>');
}
?>