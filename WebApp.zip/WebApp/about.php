<?php
	require("Login_CheckUser.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>About</title>
<?php require('Includes/meta.php');?>
</head>
<body>
<header>
  <?php require('Includes/Header.php');?>
</header>

<section id="content">
  <div class="container">
    <div class="row">
      <div class="grid_12">
        <h3>About Us</h3>
        <div class="extra_wrapper">
          <p class="fwn">Welcome to E-Classroom, the world's largest and successfull Connected network with qualified staff, integrated environment and Unlimited skills.</p>
        </div>
		<h3>Mission</h3>
        <div class="extra_wrapper">
          <p class="fwn">Our mission is simple: To create motivated opportunity for every student of each standard. When you join E-Classroom, you get access to Teacher and detailed and well explained information. </p>
        </div>
		<h3>Company Info</h3>
        <div class="extra_wrapper">
          <p class="fwn">E-Classroom started with a linkage goal with student to Teacher for making good relationship with each other’s. We appreciate all our users for trustable manner on us by providing a good service. Our company is growing up and users are being rising day by day. Members of the media may direct inquiries to <strong>info@eclassroom.com</strong></p>
        </div>
      </div>
    </div>
  </div>
</section>
<?php require('Includes/Footer.php');?>
</body>
</html>