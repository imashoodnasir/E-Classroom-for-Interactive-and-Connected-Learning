<?php
	require("Login_Check.php");
	if($_SESSION['User_Role'] != 'Admin')
		header("Location:Login.php");
?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Add New Course</title>
		<?php
			require("includes/meta.php");
		?>
	</head>
	<body>

	<?php
		require("includes/Header.php");
	?>

	<section id="content">
	  <div class="container">
		<div class="row">
		  
		  <div class="grid_5">
		  <div class="grid_12">
			<h3 class="head__1">Add New Course <span style="font-size: 18px; float: right"><a href="ManageCoursesAdmin.php">Back to Courses</a></span></h3>
			<div class="fwn">
			  <p>Kindly fill out the following form to Add New Course.</p>
			  <p>If you have problems with updation, you can <a href="contacts.php" rel="nofollow" class="color1">Click here</a> to contact us.</p>
			</div>
				  <form id="contact-form" method="POST" enctype="multipart/form-data">
					  <div class="contact-form-loader"></div>
					  <fieldset>
						<p>Fill the Following information to add new course.</p>
						<label class="phone">
						  <input type="text" class="required" name="Subject_Title" placeholder="Course Title" value="" />
						</label>
						
						<label class="name">
						  <input type="text" class="required" name="Course_Code" placeholder="Course Code" value=""/>
						</label>
						
						<div class="clear"></div>
						<div>
							
						  <input type="submit" class="btn" name="Update" onclick="return ValidateForm();" value="Add New Course" style="float: left; cursor:pointer;">
						</div>
					  </fieldset> 
					</form>   
		  </div>
		</div>
	  </div>
	</section>

	<?php
		require("includes/footer.php");
	?>

	<a href="#" id="toTop" class="fa fa-chevron-up"></a>
	</body>
</html>

<?php
	include("includes/db_connection.php");
	if(isset($_POST['Update']))
	{
		$Subject_Title = $_POST['Subject_Title'];
		$Course_Code = $_POST['Course_Code'];

		$query = "INSERT INTO tblsubjects (Subject_Title, Course_Code, isActive)
				  VALUES ('$Subject_Title', '$Course_Code', 'Yes')";
		$status = mysql_query($query);
		if($status)
			echo "<script>showSuccessMessage('Course Successfully Added!')</script>";
		else
			echo "<script>showErrorMessage('Course is not Successfully Added!')</script>";
	}
?>