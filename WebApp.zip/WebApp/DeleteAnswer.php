<?php
	if(isset($_GET['i']))
	{
		$ID = $_GET['i'];
	}
	include("includes/db_connection.php");
	$sql = "Delete FROM tblanswers WHERE ID='$ID'";
	$result = mysql_query($sql);
	header('Location: ' . $_SERVER['HTTP_REFERER']);
?>
