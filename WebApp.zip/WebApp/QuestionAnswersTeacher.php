<?php
	require("Login_Check.php");
	if($_SESSION['User_Role'] != 'Teacher')
		header("Location:Login.php");
	include("includes/db_connection.php");
	if(isset($_SESSION['User_ID']))
	{
		$User_ID = $_SESSION['User_ID'];
		$query = "SELECT  u.*, r.RoleTitle FROM tblusers u join tblroles r on u.Role = r.ID WHERE u.User_ID='$User_ID'";
		$status = mysql_query($query);
		IF($row = mysql_fetch_array($status))
		{
			$FirstName = $row['FirstName'];
			$LastName = $row['LastName'];
			$Username = $row['Username'];
			$RegNo = $row['RegNo'];
			$Email = $row['Email'];
			$ProfilePic = $row['ProfilePic'];
			$RoleTitle = $row['RoleTitle'];
		}
	}
	if(isset($_GET["qId"]))
		$qId = $_GET["qId"];
	if($qId)
	{
		include("includes/db_connection.php");
		$query = "SELECT Question FROM tblquestion WHERE ID = '$qId'";
		$status = mysql_query($query);
		if($row = mysql_fetch_array($status))
		{
			$Question = $row['Question'];
		}
	}
	
?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>Manage Questions</title>

<?php
	require("includes/meta.php");
?>

</head>
<body>

<?php
	require("includes/Header.php");
?>

<section id="content"><div class="ic"></div>
  <div class="container">
    <div class="row">
      <div class="grid_12">
        <h3 style="line-height: 0px; margin-bottom: 40px;">Teacher Profile</h3>
        <div style="width: 25%; float: left;">
		<img src="images/userPicture/<?php echo $ProfilePic;?>" style="height: 180px; margin-bottom: 20px;" alt="" class="img_inner fleft">
		<table style="width:100%">
				<tr>
					<td><p class="fwn">Registration No: <strong><?php echo $RegNo;?></strong></p></td>
				</tr>
				<tr>
					<td><p class="fwn">Username: <strong><?php echo $Username;?></strong></p></td>
				</tr>
				<tr>
					<td><p class="fwn">Email: <strong><?php echo $Email;?></strong></p></td>
				</tr>
				<tr>
					<td><p class="fwn"><a href="editProfileTeacher.php">Edit Profile</p></td>
				</tr>
				<tr>
					<td><p class="fwn"><a href="ChangePasswordTeacher.php">Change Password</p></td>
				</tr>
				<tr>
					<td><p class="fwn"><a href="ChangeProfileTeacher.php">Change Profile Picture</p></td>
				</tr>
			</table>
			</div>
        <div class="extra_wrapper"  style="width: 70%; float: right;">
          <blockquote class="bq1">
            <h3 style="padding-top: 0px; margin-bottom: -20px;">Manage Questions <span style="font-size: 18px; float: right"><a href="ManageQuestions.php">Back to Questions</a></span></h3>
			<pre class='spnQuestion' style="font-size: 20px; line-height: 33px;" ><?php echo $Question; ?></pre>
			<table width="100%" style="margin-top: 20px; border-collapse: initial; border-spacing: 3px;" border="1">
				<tr style="background-color: #00B1BA; color: white;">
					<th>No.</th>
					<th>Answer</th>
					<th>Answered By</th>
					<th>Answered On</th>
					<th>Accepted</th>
					<th>Delete</th>
				</tr>
				<?php
					$count= 0;
					$Query = "SELECT * FROM tblanswers WHERE QuestionId='$qId'";
					$Status = mysql_query($Query);
					WHILE($Row = mysql_fetch_array($Status))
					{
						$ID = $Row['ID'];
						$Answer = $Row['Answer'];
						$IsApproved = $Row['IsApproved'];
						$UserId = $Row['UserId'];
						$AnswerDate = $Row['AnswerDate'];
						$Userquery = "SELECT * FROM tblusers WHERE User_ID='$UserId'";
						$Userstatus = mysql_query($Userquery);
						IF($Userrow = mysql_fetch_array($Userstatus))
						{
							$FirstName = $Userrow['FirstName'];
							$LastName = $Userrow['LastName'];
							$Name = "$FirstName $LastName";
						}
						$count++;
						if(($count%2) == 0)
							$class="even";
						else
							$class="odd";
						echo "<tr class='$class'>
								<td>$count</td>
								<td>$Answer</td>
								<td>$Name</td>
								<td>$AnswerDate</td>";
								if($IsApproved == 'Yes')
									echo "<td><a href='AnswerReject.php?i=$ID' onclick='return Rejectconfig()'><u>Yes</u></a></td>";
								else if($IsApproved == 'No')
									echo "<td><a href='AnswerAccept.php?i=$ID' onclick='return Acceptconfig()'><u>No</u></a></td>";
								echo "<td><a href='DeleteAnswer.php?i=$ID' onclick='return DeleteAnswer()'><u>Delete</u></a></td>";
							echo "</tr>";
					}
				?>
			</table>
          </blockquote>
        </div>
      </div>
    </div>
  </div>
</section>

<?php
	require("includes/footer.php");
?>

<a href="#" id="toTop" class="fa fa-chevron-up"></a>
</body>
</html>

<?php
	if(isset($_POST['Upload']))
	{
		$FileName = $_POST['FileName'];
		$Subject_ID = $_POST['Subject'];
		if(isset($_FILES['DocumentFile']))
		{
			$random_key = substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 30);
			$DocumentFile = $_FILES['DocumentFile']['name'];
			$temp_name= $_FILES['DocumentFile']['tmp_name'];
			move_uploaded_file($temp_name, "User_Documents/$random_key$DocumentFile");
			$DocumentFile = "$random_key$DocumentFile";
			$offset=5*60*60;
			$dateFormat="d-m-Y H:i:s";
			$CurrentDateTime=gmdate($dateFormat, time()+$offset);
		}
		$query = "INSERT INTO tbllibrary (User_ID, Subject_ID, DocumentFile, DocumentName, UploadDate) VALUES ('$User_ID', '$Subject_ID', '$DocumentFile', '$FileName', '$CurrentDateTime')";
		$status = mysql_query($query);
		if($status)
		{
			echo "<meta http-equiv='refresh' content='0'>";
		}
	}
?>