<?php
	require("Login_Check.php");
	if($_SESSION['User_Role'] != 'Teacher')
		header("Location:Login.php");
	if(isset($_GET['i']))
	{
		$ID = $_GET['i'];
	}
	include("includes/db_connection.php");
	$sql = "UPDATE tblquestion SET IsApproved='Yes' WHERE ID='$ID'";
	$result = mysql_query($sql);
	header('Location: ' . $_SERVER['HTTP_REFERER']);
?>
