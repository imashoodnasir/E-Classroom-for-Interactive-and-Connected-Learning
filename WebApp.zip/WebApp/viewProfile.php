<?php
	require("Login_Check.php");
	include("includes/db_connection.php");
	if(isset($_SESSION['User_ID']))
	{
		$User_ID = $_SESSION['User_ID'];
		$query = "SELECT  u.*, r.RoleTitle FROM tblusers u join tblroles r on u.Role = r.ID WHERE u.User_ID='$User_ID'";
		$status = mysql_query($query);
		IF($row = mysql_fetch_array($status))
		{
			$User_ID = $row['User_ID'];
			$FirstName = $row['FirstName'];
			$LastName = $row['LastName'];
			$Username = $row['Username'];
			$RegNo = $row['RegNo'];
			$Email = $row['Email'];
			$ProfilePic = $row['ProfilePic'];
			$RoleTitle = $row['RoleTitle'];
			$DOB = $row['DOB'];
			$Phone = $row['Phone'];
			$EmailVerification = $row['EmailVerification'];
			$CurrentLoginTime = $row['CurrentLoginTime'];
			$LastLogin = $row['LastLogin'];
			$LoginCounts = $row['LoginCounts'];
		}
	}
	
?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>Company Profile</title>

<?php
	require("includes/meta.php");
?>

</head>
<body>

<?php
	require("includes/Header.php");
?>

<section id="content"><div class="ic"></div>
  <div class="container">
    <div class="row">
      <div class="grid_12">
        <h3 style="line-height: 0px;"><?php echo "$FirstName $LastName";?><span style="float: right; font-size: 24px;"><a href="editProfile.php">Edit Details</a></span></h3>
        <h3 style="font-size: 20px; line-height: 0px;">Role: <?php echo $RoleTitle;?></h3>
        <img src="images/userPicture/<?php echo $ProfilePic;?>" style="height: 180px;" alt="" class="img_inner fleft">
        <div class="extra_wrapper">
          <table style="width: 100%">
				<tr>
					<td><p class="fwn">Registration No: <strong><?php echo $RegNo;?></strong></p></td>
					<td><p class="fwn">Username: <strong><?php echo $Username;?></strong></p></td>
					<td><p class="fwn">Phone: <strong><?php echo $Phone;?></strong></p></td>
				</tr>
				<tr>
					<td colspan="2">
						<p class="fwn">Email: <strong><?php echo $Email;?></strong>
						<?php
							if($EmailVerification == 'Yes')
								echo "<img src='images/tick.png' title='Email Verified!' style='width: 20px; height: 20px;'/>";
							else if($EmailVerification == 'No')
							{
								$mystring = base64_encode("$User_ID*$Email"); 
								echo "<img src='images/cross.png'  title='Email is not Verified!' style='width: 20px; height: 20px;'/><a href='verifyEmail.php?e=$mystring'><span style='color: blue;'>Verify Now</a></a>";
							}
						?>
						</p>
					</td>
					<td><p class="fwn">Date of Birth: <strong><?php echo "$DOB";?></strong></p></td>
				</tr>
				<tr>
					<td><p class="fwn">Current Login Time: <strong><?php echo "$CurrentLoginTime";?></strong></p></td>
					<td><p class="fwn">Last Login: <strong><?php echo "$LastLogin";?></strong></p></td>
					<td><p class="fwn">Login Counts: <strong><?php echo "$LoginCounts";?></strong></p></td>
				</tr>
			</table>
        </div>
      </div>
    </div>
  </div>
</section>

<?php
	require("includes/footer.php");
?>

<a href="#" id="toTop" class="fa fa-chevron-up"></a>
</body>
</html>