<?php
	require("Login_CheckUser.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Home</title>
<?php require('Includes/meta.php');?>
</head>
<body class="page1" id="top">

<header>
<?php require('Includes/Header.php');?>
  <section class="page1_header">
    <div class="container">
      <div class="row">
        <div class="grid_4">
          <a href="login.php" class="banner "><div class="maxheight">
            <div class="fa fa-globe"></div>Student Login</div>
          </a>
          <a href="login.php" class="banner "><div class="maxheight">
            <div class="fa fa-briefcase"></div>Teacher Login</div>
          </a>
          <a href="login.php" class="banner "><div class="maxheight1">
            <div class="fa fa-cog"></div>Admin Login</div>
          </a>
          <a href="login.php" class="banner "><div class="maxheight1">
            <div class="fa fa-lightbulb-o"></div>Ask Question</div>
          </a>
        </div>
        <div class="grid_5">
          <h2>EClassroom <br> Interactive and <br> Connected Learning</h2>
          We help you in a most better way!!
        </div>
      </div>
    </div>
  </section>
</header>
<div class="block-1">
  <div class="container">
    <div class="row">
      <div class="grid_3">
	  <?php
		include("includes/db_connection.php");
		$sql=mysql_query("select * from tblsubjects");
		$subjects_count=mysql_num_rows($sql);
	  ?>
        <div class="block-1_count"><?php echo $subjects_count;?></div>
        Number of <br> Subjects
        <div class="clear"></div>
      </div>
      <div class="grid_3">
	  <?php
		$sql=mysql_query("select * from tblusers WHERE Role='3'");
		$Students_count=mysql_num_rows($sql);
	  ?>
        <div class="block-1_count"><?php echo $Students_count;?></div>
        Number of <br> Students
        <div class="clear"></div>
      </div>
      <div class="grid_3">
	  <?php
		$sql=mysql_query("select * from tblquestion");
		$question_count=mysql_num_rows($sql);
	  ?>
        <div class="block-1_count"><?php echo $question_count;?></div>
        Asked <br> Questions
        <div class="clear"></div>
      </div>
      <div class="grid_3">
        <a href="#" class="support"><img src="images/support.png" alt=""></a>
      </div>
    </div>
  </div>
</div>

<section id="content">
  <div class="container">
    <div class="row">
      <div class="grid_10 preffix_1 ta__center">
        <div class="greet">
          <h2 class="head__1">
            Welcome
          </h2>
          <p>to the eClassroom for interactive and Connected Learning.</p>
          Here you can manage your documents as per your subjects, get answers of the questions from a Chatbot.
		If you cannot find your question, you can ask it here. Once approved from the admin or the subject teacher, the community will be able to provide you a relative answer. 
        </div>
      </div>
    </div>
  </div>
  <article class="content_gray">
    <div class="container">
      <div class="row">
        <div class="grid_7">
          <h3>Our Advantages</h3>
          <div class="block-2">
            <img src="images/EasyHelp.jpg" alt="" class="img_inner fleft" style="height: 170px;">
            <div class="extra_wrapper">
              <div class="text1">Easy to Get Help</div>
              <p>Queries at home? You can ask a question and your question will be answered by your community once it is accepted by admin or your teacher.</p>
                 Answers are also validated before they are published to give the best possible results to the users.
              <br>
            </div>
          </div>
          <div class="block-2">
            <img src="images/EasyManagement.jpg" alt="" class="img_inner fleft" style="height: 170px;">
            <div class="extra_wrapper">
              <div class="text1">Easy to Manage Stuff</div>
              <p>Have some notes or files, which can be helpful during class? Upload those files in your account and use them during class via our Windows Application.</p>
                 You can add Text Files (*.txt), Word Files (*.doc or *.docx) and PDF Files (*.pdf).
              <br>
            </div>
          </div>
        </div>
        <div class="grid_4 preffix_1">
          <h3>Testimonials</h3>
          <blockquote class="bq1">
            <p>“Its always Pleasure to use this company to get the knowledge of all the related questions of my interest... High Five!!”</p>
            <span>Ehtasham Mehmood</span>
          </blockquote>
          <blockquote class="bq1">
            <p>“The website is developed with an excellent technique and it's searching machanism for answers is simply outstanding... Highly Informative... Highly Recommended as well.”</p>
            <span>Inzamam Mashood</span>
          </blockquote>
        </div>
      </div>
    </div>
  </article>
</section>
<?php require('Includes/Footer.php');?>
</body>
</html>