<?php
	require("Login_Check.php");
	if($_SESSION['User_Role'] != 'Admin')
		header("Location:Login.php");
	if(isset($_GET['i']))
	{
		$User_ID = $_GET['i'];
	}
	include("includes/db_connection.php");
	$sql = "Delete FROM tblusers WHERE User_ID='$User_ID'";
	$result = mysql_query($sql);
	header('Location: ' . $_SERVER['HTTP_REFERER']);
?>
