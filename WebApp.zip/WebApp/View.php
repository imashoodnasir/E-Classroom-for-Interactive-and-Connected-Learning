<?php
	echo "<html><head>";
	echo "<title>Document View</title></head><body>";
	include("includes/db_connection.php");
	if(isset($_GET['i']))
	{
		$ID = $_GET['i'];
	}
	$sql = "SELECT DocumentFile FROM tbllibrary WHERE ID='$ID'";
	$result = mysql_query($sql);
	if($row = mysql_fetch_array($result))
	{
		$DocumentFile = $row['DocumentFile'];
	}
	$filename = $DocumentFile;
	$path = "User_Documents/$filename";
	header('Content-Type: application/pdf');
	header("Content-Transfer-Encoding: Binary");
	header("Content-Disposition: attachment; filename=$filename");
	header('Accept-Ranges: bytes');
	@readfile($path);
	echo "</body></html>";
?>
