<?php 
	require("Login_Check.php");
	if(isset($_REQUEST["qId"]))
		$qId = $_REQUEST["qId"];
	echo "<input type='hidden' id='hiddenQId' value='$qId'>";
	if($qId)
	{
		include("includes/db_connection.php");
		$query = "SELECT Question FROM tblquestion WHERE IsApproved = 'Yes' AND ID = '$qId'";
		$status = mysql_query($query);
		if($row = mysql_fetch_array($status))
		{
			$Question = $row['Question'];
			$Question = str_replace("/&/g", '&amp;', $Question);
			$Question = str_replace("/</g", '&lt;', $Question);
			$Question = str_replace("/>/g", '&gt;', $Question);
		}
		echo "<div class='divQuestionAns'>
				<h4><pre class='spnQuestionAns'>$Question</pre></h4>
			</div>";
		$status = mysql_query($query);
		$query = "SELECT a.*, u.FirstName, u.LastName, u.ProfilePic FROM tblanswers a JOIN tblusers u ON a.UserId = u.User_ID WHERE a.IsApproved = 'Yes' AND a.QuestionId = '$qId'";
		$status = mysql_query($query);
		echo "<div id='answers'>";
		WHILE($row = mysql_fetch_array($status))
		{
			$Answer = $row['Answer'];
			$Answer = str_replace("/&/g", '&amp;', $Answer);
			$Answer = str_replace("/</g", '&lt;', $Answer);
			$Answer = str_replace("/>/g", '&gt;', $Answer);
			$FirstName = $row['FirstName'];
			$LastName = $row['LastName'];
			$ProfilePic = $row['ProfilePic'];
			$Name = " $FirstName $LastName";
			$Answer = $row['Answer'];
			$AnswerDate = $row['AnswerDate'];
			$ID = $row['ID'];
			echo "<div class='divAnswer' style='width: 96%;float:left;background-color:rgba(204, 204, 204, 0.38); margin:1%;padding:1%;'>
					<div style='width: 100%;color:#00A6BA;float:left'>
						<pre style='width: 100%;'>$Answer</pre>
					</div>
					<div style='background-color: #969696;height: 47px;padding: 8px; width: 40%;float: right;margin-bottom: 3px; color: white;border-radius: 5px;'>
						<span style='width:100%; font-size: 12px; float:left'>Answered at $AnswerDate</span>
						<span style='float:left'><img src='images/userPicture/$ProfilePic' style='width: 30px; height: 30px;'></span>
						<span style='font-size: 14px; margin-left: 5px; float:left;'>$Name</span>
					</div>
				</div>";
		}
		echo "</div>";
		echo "<div style='margin-top: 10px;'>
				<textarea cols='97' rows='5' class='required' id='taAddAnswer' style='resize:none'></textarea>
				<input type='submit' class='btn'  id='saveAnswerNew' value='Save Answer'/>
			</div>";
	}
?>