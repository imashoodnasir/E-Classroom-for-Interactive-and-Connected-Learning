<?php
	require("Login_Check.php");
	if($_SESSION['User_Role'] != 'Admin')
		header("Location:Login.php");
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Add New User</title>
		<?php
			require("includes/meta.php");
		?>
	</head>
	<body>

	<?php
		require("includes/Header.php");
	?>

	<section id="content">
	  <div class="container">
		<div class="row">
		  
		  <div class="grid_5">
		  <div class="grid_12">
			<h3 class="head__1">Add New User <span style="font-size: 18px; float: right"><a href="ManageUsers.php">Back to Users</a></span></h3>
			<div class="fwn">
			  <p>Kindly fill out the following form to Add New User.</p>
			  <p>If you have problems with updation, you can <a href="contacts.php" rel="nofollow" class="color1">Click here</a> to contact us.</p>
			</div>
				  <form id="contact-form" method="POST" enctype="multipart/form-data">
					  <div class="contact-form-loader"></div>
					  <fieldset>
						<p>Fill the Following information to add new user.</p>
						<label class="phone">
						  <input type="text" class="required" name="RegNo" placeholder="Registration No:" value="" />
						</label>
						
						<label class="name">
						  <input type="text" class="required" name="Username" placeholder="Username" value=""/>
						</label>
						
						<label class="name" style=" width: 270px;">
							<select name="Role" class="required">
								<option selected class="required" disabled>--SELECT Role--</option>
								<?php
									include("includes/db_connection.php");
									$query = "SELECT * FROM tblroles WHERE isActive='Yes'";
									$status = mysql_query($query);
									WHILE($row = mysql_fetch_array($status))
									{
										$ID = $row['ID'];
										$RoleTitle = $row['RoleTitle'];
										echo "<option value='$ID'>$RoleTitle</option>";
									}
								?>
							</select>
						</label>
						
						<label class="name"  style="margin-left: 0px">
						  <input type="email" class="required" name="Email" placeholder="Email:" value="" />
						</label>
						
						<label class="name" >
						  <input type="text" class="required" name="Phone" placeholder="Phone:" onkeypress="return ValidateOnlyNumber(event);" value="" />
						</label>
						
						<div class="clear"></div>
						<div>
							
						  <input type="submit" class="btn" name="Update" onclick="return ValidateForm();" value="Add New User" style="float: left; cursor:pointer;">
						</div>
					  </fieldset> 
					</form>   
		  </div>
		</div>
	  </div>
	</section>

	<?php
		require("includes/footer.php");
	?>

	<a href="#" id="toTop" class="fa fa-chevron-up"></a>
	</body>
</html>

<?php
	if(isset($_POST['Update']))
	{
		$User_ID = substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 30);
		$RegNo = $_POST['RegNo'];
		$Username = $_POST['Username'];
		$Email = $_POST['Email'];
		$Role = $_POST['Role'];
		$Phone = $_POST['Phone'];

		$query = "INSERT INTO tblusers (User_ID, FirstName, LastName, DOB, ProfilePic, RegNo, Username, Password, Email, Role, Phone, isAccepted, isBlocked)
				  VALUES ('$User_ID', 'Set Yourself', 'Set Yourself', 'Set Yourself', 'dummy.jpg', '$RegNo', '$Username', '123', '$Email', '$Role', '$Phone', 'Yes', 'No')";
		$status = mysql_query($query);
		if($status)
			echo "<script>showSuccessMessage('User Successfully Added!')</script>";
		else
			echo "<script>showErrorMessage('User is not Successfully Added!')</script>";
	}
?>