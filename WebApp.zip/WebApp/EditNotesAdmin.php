<?php
	require("Login_Check.php");
	include("includes/db_connection.php");
	if(isset($_SESSION['User_ID']))
	{
		$User_ID = $_SESSION['User_ID'];
		$query = "SELECT  u.*, r.RoleTitle FROM tblusers u join tblroles r on u.Role = r.ID WHERE u.User_ID='$User_ID'";
		$status = mysql_query($query);
		IF($row = mysql_fetch_array($status))
		{
			$FirstName = $row['FirstName'];
			$LastName = $row['LastName'];
			$Username = $row['Username'];
			$RegNo = $row['RegNo'];
			$Email = $row['Email'];
			$ProfilePic = $row['ProfilePic'];
			$RoleTitle = $row['RoleTitle'];
		}
	}
	if(isset($_GET['u']))
	{
		$User_ID = $_GET['u'];
	}
	if(isset($_GET['i']))
	{
		$ID = $_GET['i'];
		$query = "SELECT * FROM tblNotes WHERE User_ID='$User_ID' AND ID='$ID'";
		$status = mysql_query($query);
		IF($row = mysql_fetch_array($status))
		{
			$NotesContent = $row['NotesContent'];
			$Subject_ID = $row['Subject_ID'];
			$NotesTitle = $row['NotesTitle'];
		}
	}
	
?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>Edit Notes</title>
<script src='js/jQueryPlugins/tinymce/jscripts/tiny_mce/tiny_mce.js' type="text/javascript"></script>
<?php
	require("includes/meta.php");
?>
<script>
	$(function(){
		CreateEditor();
	});
</script>

<style>
	#elm1_parent{width: 100%;}
</style>

</head>
<body>

<?php
	require("includes/Header.php");
?>

<section id="content"><div class="ic"></div>
  <div class="container">
    <div class="row">
      <div class="grid_12">
        <h3 style="line-height: 0px; margin-bottom: 40px;">Student Profile</h3>
        <div style="width: 25%; float: left;">
		<img src="images/userPicture/<?php echo $ProfilePic;?>" style="height: 180px; margin-bottom: 20px;" alt="" class="img_inner fleft">
		<table style="width:100%">
				<tr>
					<td><p class="fwn">Registration No: <strong><?php echo $RegNo;?></strong></p></td>
				</tr>
				<tr>
					<td><p class="fwn">Username: <strong><?php echo $Username;?></strong></p></td>
				</tr>
				<tr>
					<td><p class="fwn">Email: <strong><?php echo $Email;?></strong></p></td>
				</tr>
				<tr>
					<td><p class="fwn"><a href="editProfile.php">Edit Profile</p></td>
				</tr>
				<tr>
					<td><p class="fwn"><a href="forgetPassword.php">Change Password</p></td>
				</tr>
			</table>
			</div>
        <div class="extra_wrapper"  style="width: 70%; float: right;">
          <blockquote class="bq1">
            <h3 style="padding-top: 0px; margin-bottom: -20px;">Edit Notes<span style="font-size: 18px; float: right"><a href="UploadNotesAdmin.php">Back to Notes</a></span></h3>
            <form method="POST" id="contact-form" enctype="multipart/form-data">
				<div class="contact-form-loader"></div>
				<div class="contact-form-loader"></div>
				<fieldset>
					<label class="name" style="width: 270px;">
						<input type="text" class="required" name="NotesTitle" placeholder="Note's Title:" value="<?php echo $NotesTitle;?>"/>
					</label>
					<label class="name" style=" width: 270px;">
					  <select name="Subject" class="required">
						<option class="required" disabled>--SELECT Subject--</option>
						<?php
							include("includes/db_connection.php");
							$query = "SELECT * FROM tblsubjects WHERE isActive='Yes'";
							$status = mysql_query($query);
							WHILE($row = mysql_fetch_array($status))
							{
								$ID = $row['ID'];
								$Subject_Title = $row['Subject_Title'];
								if($ID == $Subject_ID)
									echo "<option selected value='$ID'>$Subject_Title</option>";
								else
									echo "<option value='$ID'>$Subject_Title</option>";
							}
						?>
						</select>
					</label><br/><br/><br/>
					<div><textarea id="elm1" name="mailContents" rows="15" cols="80" style="width: 100%; resize: none; margin-left: 10px;"></textarea></div>
                    <input type="Hidden" ID="hdnDescription" name="NotesContent" Value="<?php echo $NotesContent;?>"/>
					<div style="width: 100%; float: left;">
						<input type="submit" class="btn" name="Upload" value="Update" onclick="return ValidateForm(); return showalert();" style="float: left; cursor:pointer;"/>
					</div>
				</fieldset>
			</form>
          </blockquote>
        </div>
      </div>
    </div>
  </div>
</section>

<?php
	require("includes/footer.php");
?>

<a href="#" id="toTop" class="fa fa-chevron-up"></a>
</body>
</html>

<?php
	if(isset($_POST['Upload']))
	{
		$NotesTitle = $_POST['NotesTitle'];
		$Subject_ID = $_POST['Subject'];
		$NotesContent = $_POST['NotesContent'];
		$offset=5*60*60;
		$dateFormat="d-m-Y H:i:s";
		$CurrentDateTime=gmdate($dateFormat, time()+$offset);
		$query = "UPDATE `tblnotes` SET `Subject_ID`='$Subject_ID',`NotesTitle`='$NotesTitle',`NotesContent`='$NotesContent',`UploadDate`='CurrentDateTime' WHERE User_ID='$User_ID'";
		$status = mysql_query($query);
		if($status)
			echo "<script>showSuccessMessage('Notes is Successfully Uploaded!')</script>";
		else
			echo "<script>showErrorMessage('Error is Saving Notes')</script>";
	}
?>