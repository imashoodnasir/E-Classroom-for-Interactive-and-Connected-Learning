<?php
	require("Login_Check.php");
	if($_SESSION['User_Role'] != 'Admin')
		header("Location:Login.php");
	if(isset($_GET['i']))
	{
		$ID = $_GET['i'];
	}
	include("includes/db_connection.php");
	$sql = "SELECT isActive FROM tblsubjects WHERE ID='$ID'";
	$result = mysql_query($sql);
	if($row = mysql_fetch_array($result))
	{
		$isActive = $row['isActive'];
	}
	$query = "";
	if($isActive == "Yes")
		$query = "UPDATE tblsubjects SET isActive='No' WHERE ID='$ID'";
	else if($isActive == "No")
		$query = "UPDATE tblsubjects SET isActive='Yes' WHERE ID='$ID'";
	$result = mysql_query($query);
	header('Location: ' . $_SERVER['HTTP_REFERER']);
?>
