﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Windows.Forms;

namespace EClassRoom
{
    public partial class AvailableQuiz : Form
    {
        public AvailableQuiz()
        {
            InitializeComponent();
        }

        private void lblManage_MouseHover(object sender, EventArgs e)
        {
            lblManage.ForeColor = Color.Red;
        }

        private void lblManage_MouseLeave(object sender, EventArgs e)
        {
            lblManage.ForeColor = Color.Black;
        }

        private void lblManage_Click(object sender, EventArgs e)
        {
            lblManage.Font = new Font("Microsoft Sans Serif", 9, FontStyle.Bold);
            panelInternetBrowsing.Visible = true;

            lblTitle.Text = "Current Quiz";
        }

        private void Users_Load(object sender, EventArgs e)
        {
            panelInternetBrowsing.Visible = true;
            DBManager objDBManager = new DBManager();
            DataTable dt = objDBManager.ReturnDataTable("select q.Question from tblquiz t join tblquestion q on t.Question = q.ID where IsActive = 'Yes'");
            if (dt.Rows.Count > 0)
            {
                lblCurrentQuiz.Text = HttpUtility.UrlDecode(dt.Rows[0]["Question"].ToString());
            }
        }

        private void menuItemManageUsers_Click(object sender, EventArgs e)
        {
            ManageNotes mn = new ManageNotes();
            mn.FormClosed += new FormClosedEventHandler(db_FormClosed);
            mn.Show();
            this.Hide();
        }

        private void db_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Close();
        }

        private void menuItemDashboard_Click(object sender, EventArgs e)
        {
            Dashboard db = new Dashboard();
            db.FormClosed += new FormClosedEventHandler(db_FormClosed);
            db.Show();
            this.Hide();
        }

        private void MenuItemHome_Click(object sender, EventArgs e)
        {
            MainForm mf = new MainForm();
            mf.FormClosed += new FormClosedEventHandler(db_FormClosed);
            mf.Show();
            this.Hide();
        }


        private void menuItemManageInventory_Click(object sender, EventArgs e)
        {
            ManageDocuments md = new ManageDocuments();
            md.FormClosed += new FormClosedEventHandler(db_FormClosed);
            md.Show();
            this.Hide();
        }

        private void menuItemManageEmployees_Click(object sender, EventArgs e)
        {
            InternetBrowsing ib = new InternetBrowsing();
            ib.FormClosed += new FormClosedEventHandler(db_FormClosed);
            ib.Show();
            this.Hide();
        }

        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MainForm mf = new MainForm();
            mf.FormClosed += new FormClosedEventHandler(db_FormClosed);
            mf.Show();
            this.Hide();
        }

        private void menuItemExpenses_Click(object sender, EventArgs e)
        {
            LiveChat aq = new LiveChat();
            aq.FormClosed += new FormClosedEventHandler(db_FormClosed);
            aq.Show();
            this.Hide();
        }
    }
}
