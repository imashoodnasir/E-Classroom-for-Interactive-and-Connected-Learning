﻿namespace EClassRoom
{
    partial class InternetBrowsing
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(InternetBrowsing));
            this.SubMenu = new System.Windows.Forms.MenuStrip();
            this.menuItemDashboard = new System.Windows.Forms.ToolStripMenuItem();
            this.menuItemManageUsers = new System.Windows.Forms.ToolStripMenuItem();
            this.menuItemManageInventory = new System.Windows.Forms.ToolStripMenuItem();
            this.menuItemManageEmployees = new System.Windows.Forms.ToolStripMenuItem();
            this.menuItemManageSales = new System.Windows.Forms.ToolStripMenuItem();
            this.menuItemExpenses = new System.Windows.Forms.ToolStripMenuItem();
            this.MainMenu = new System.Windows.Forms.MenuStrip();
            this.MenuItemLogout = new System.Windows.Forms.ToolStripMenuItem();
            this.logoutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItemHome = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.lblManage = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.panelFooter = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lblTitle = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panelHistory = new System.Windows.Forms.Panel();
            this.lblBottom = new System.Windows.Forms.Label();
            this.lblTop = new System.Windows.Forms.Label();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.btnForward = new System.Windows.Forms.Button();
            this.btnHome = new System.Windows.Forms.Button();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.btnGo = new System.Windows.Forms.Button();
            this.btnStop = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.WebBrowser = new System.Windows.Forms.WebBrowser();
            this.SubMenu.SuspendLayout();
            this.MainMenu.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panelFooter.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panelHistory.SuspendLayout();
            this.SuspendLayout();
            // 
            // SubMenu
            // 
            this.SubMenu.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.SubMenu.GripStyle = System.Windows.Forms.ToolStripGripStyle.Visible;
            this.SubMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuItemDashboard,
            this.menuItemManageUsers,
            this.menuItemManageInventory,
            this.menuItemManageEmployees,
            this.menuItemManageSales,
            this.menuItemExpenses});
            this.SubMenu.Location = new System.Drawing.Point(0, 24);
            this.SubMenu.Name = "SubMenu";
            this.SubMenu.Padding = new System.Windows.Forms.Padding(3, 12, 0, 2);
            this.SubMenu.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.SubMenu.Size = new System.Drawing.Size(809, 33);
            this.SubMenu.TabIndex = 49;
            this.SubMenu.Text = "menuStrip2";
            // 
            // menuItemDashboard
            // 
            this.menuItemDashboard.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.menuItemDashboard.ForeColor = System.Drawing.Color.Black;
            this.menuItemDashboard.Name = "menuItemDashboard";
            this.menuItemDashboard.Size = new System.Drawing.Size(76, 19);
            this.menuItemDashboard.Text = "Dashboard";
            this.menuItemDashboard.Click += new System.EventHandler(this.menuItemDashboard_Click);
            // 
            // menuItemManageUsers
            // 
            this.menuItemManageUsers.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.menuItemManageUsers.ForeColor = System.Drawing.Color.Black;
            this.menuItemManageUsers.Name = "menuItemManageUsers";
            this.menuItemManageUsers.Size = new System.Drawing.Size(96, 19);
            this.menuItemManageUsers.Text = "Manage Notes";
            this.menuItemManageUsers.Click += new System.EventHandler(this.menuItemManageUsers_Click);
            // 
            // menuItemManageInventory
            // 
            this.menuItemManageInventory.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.menuItemManageInventory.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.menuItemManageInventory.Name = "menuItemManageInventory";
            this.menuItemManageInventory.Size = new System.Drawing.Size(126, 19);
            this.menuItemManageInventory.Text = "Manage Documents";
            this.menuItemManageInventory.Click += new System.EventHandler(this.menuItemManageInventory_Click);
            // 
            // menuItemManageEmployees
            // 
            this.menuItemManageEmployees.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.menuItemManageEmployees.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.menuItemManageEmployees.Name = "menuItemManageEmployees";
            this.menuItemManageEmployees.Size = new System.Drawing.Size(121, 19);
            this.menuItemManageEmployees.Text = "Internet Browsing";
            // 
            // menuItemManageSales
            // 
            this.menuItemManageSales.Name = "menuItemManageSales";
            this.menuItemManageSales.Size = new System.Drawing.Size(94, 19);
            this.menuItemManageSales.Text = "Available Quiz";
            this.menuItemManageSales.Click += new System.EventHandler(this.menuItemManageSales_Click);
            // 
            // menuItemExpenses
            // 
            this.menuItemExpenses.Name = "menuItemExpenses";
            this.menuItemExpenses.Size = new System.Drawing.Size(68, 19);
            this.menuItemExpenses.Text = "Live Chat";
            this.menuItemExpenses.Click += new System.EventHandler(this.menuItemExpenses_Click);
            // 
            // MainMenu
            // 
            this.MainMenu.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.MainMenu.GripStyle = System.Windows.Forms.ToolStripGripStyle.Visible;
            this.MainMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MenuItemLogout,
            this.MenuItemHome});
            this.MainMenu.Location = new System.Drawing.Point(0, 0);
            this.MainMenu.Name = "MainMenu";
            this.MainMenu.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.MainMenu.Size = new System.Drawing.Size(809, 24);
            this.MainMenu.TabIndex = 48;
            this.MainMenu.Text = "menuStrip1";
            // 
            // MenuItemLogout
            // 
            this.MenuItemLogout.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.MenuItemLogout.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.MenuItemLogout.Checked = true;
            this.MenuItemLogout.CheckState = System.Windows.Forms.CheckState.Checked;
            this.MenuItemLogout.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.logoutToolStripMenuItem});
            this.MenuItemLogout.Name = "MenuItemLogout";
            this.MenuItemLogout.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.MenuItemLogout.RightToLeftAutoMirrorImage = true;
            this.MenuItemLogout.Size = new System.Drawing.Size(61, 20);
            this.MenuItemLogout.Text = "Options";
            // 
            // logoutToolStripMenuItem
            // 
            this.logoutToolStripMenuItem.Name = "logoutToolStripMenuItem";
            this.logoutToolStripMenuItem.Size = new System.Drawing.Size(112, 22);
            this.logoutToolStripMenuItem.Text = "Logout";
            this.logoutToolStripMenuItem.Click += new System.EventHandler(this.logoutToolStripMenuItem_Click);
            // 
            // MenuItemHome
            // 
            this.MenuItemHome.Name = "MenuItemHome";
            this.MenuItemHome.Size = new System.Drawing.Size(52, 20);
            this.MenuItemHome.Text = "Home";
            this.MenuItemHome.Click += new System.EventHandler(this.MenuItemHome_Click);
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.lblManage);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(0, 60);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 495);
            this.panel1.TabIndex = 50;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(33, 65);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(15, 16);
            this.label8.TabIndex = 57;
            this.label8.Text = ">";
            // 
            // lblManage
            // 
            this.lblManage.AutoSize = true;
            this.lblManage.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblManage.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblManage.Location = new System.Drawing.Point(54, 65);
            this.lblManage.Name = "lblManage";
            this.lblManage.Size = new System.Drawing.Size(103, 16);
            this.lblManage.TabIndex = 52;
            this.lblManage.Text = "Internet Browser";
            this.lblManage.Click += new System.EventHandler(this.lblManage_Click);
            this.lblManage.MouseLeave += new System.EventHandler(this.lblManage_MouseLeave);
            this.lblManage.MouseHover += new System.EventHandler(this.lblManage_MouseHover);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 16);
            this.label1.TabIndex = 51;
            this.label1.Text = "Main Menu";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ControlDark;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(200, 27);
            this.panel2.TabIndex = 51;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(297, 6);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(240, 13);
            this.label4.TabIndex = 30;
            this.label4.Text = "© 2016 Developed By Inzamam Mashood";
            // 
            // panelFooter
            // 
            this.panelFooter.Controls.Add(this.label4);
            this.panelFooter.Location = new System.Drawing.Point(0, 561);
            this.panelFooter.Name = "panelFooter";
            this.panelFooter.Size = new System.Drawing.Size(809, 26);
            this.panelFooter.TabIndex = 23;
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel3.Controls.Add(this.lblTitle);
            this.panel3.Controls.Add(this.pictureBox1);
            this.panel3.Location = new System.Drawing.Point(206, 60);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(595, 100);
            this.panel3.TabIndex = 51;
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Comic Sans MS", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(370, 29);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(208, 31);
            this.lblTitle.TabIndex = 1;
            this.lblTitle.Text = "Internet Browsing";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(21, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(300, 91);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel4.Location = new System.Drawing.Point(206, 166);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(595, 10);
            this.panel4.TabIndex = 52;
            // 
            // panelHistory
            // 
            this.panelHistory.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panelHistory.Controls.Add(this.lblBottom);
            this.panelHistory.Controls.Add(this.lblTop);
            this.panelHistory.Controls.Add(this.txtAddress);
            this.panelHistory.Controls.Add(this.btnForward);
            this.panelHistory.Controls.Add(this.btnHome);
            this.panelHistory.Controls.Add(this.btnRefresh);
            this.panelHistory.Controls.Add(this.btnGo);
            this.panelHistory.Controls.Add(this.btnStop);
            this.panelHistory.Controls.Add(this.btnBack);
            this.panelHistory.Controls.Add(this.WebBrowser);
            this.panelHistory.Location = new System.Drawing.Point(206, 179);
            this.panelHistory.Name = "panelHistory";
            this.panelHistory.Size = new System.Drawing.Size(595, 385);
            this.panelHistory.TabIndex = 55;
            this.panelHistory.Visible = false;
            // 
            // lblBottom
            // 
            this.lblBottom.AutoSize = true;
            this.lblBottom.Location = new System.Drawing.Point(7, 368);
            this.lblBottom.Name = "lblBottom";
            this.lblBottom.Size = new System.Drawing.Size(0, 13);
            this.lblBottom.TabIndex = 66;
            // 
            // lblTop
            // 
            this.lblTop.AutoSize = true;
            this.lblTop.Location = new System.Drawing.Point(3, 27);
            this.lblTop.Name = "lblTop";
            this.lblTop.Size = new System.Drawing.Size(0, 13);
            this.lblTop.TabIndex = 55;
            // 
            // txtAddress
            // 
            this.txtAddress.Location = new System.Drawing.Point(158, 3);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(352, 20);
            this.txtAddress.TabIndex = 65;
            // 
            // btnForward
            // 
            this.btnForward.Location = new System.Drawing.Point(25, 1);
            this.btnForward.Name = "btnForward";
            this.btnForward.Size = new System.Drawing.Size(20, 23);
            this.btnForward.TabIndex = 64;
            this.btnForward.Text = ">";
            this.btnForward.UseVisualStyleBackColor = true;
            // 
            // btnHome
            // 
            this.btnHome.Location = new System.Drawing.Point(47, 1);
            this.btnHome.Name = "btnHome";
            this.btnHome.Size = new System.Drawing.Size(48, 23);
            this.btnHome.TabIndex = 63;
            this.btnHome.Text = "Home";
            this.btnHome.UseVisualStyleBackColor = true;
            // 
            // btnRefresh
            // 
            this.btnRefresh.Location = new System.Drawing.Point(99, 1);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(55, 23);
            this.btnRefresh.TabIndex = 62;
            this.btnRefresh.Text = "Refresh";
            this.btnRefresh.UseVisualStyleBackColor = true;
            // 
            // btnGo
            // 
            this.btnGo.Location = new System.Drawing.Point(516, 1);
            this.btnGo.Name = "btnGo";
            this.btnGo.Size = new System.Drawing.Size(30, 23);
            this.btnGo.TabIndex = 61;
            this.btnGo.Text = "Go";
            this.btnGo.UseVisualStyleBackColor = true;
            // 
            // btnStop
            // 
            this.btnStop.Location = new System.Drawing.Point(549, 1);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(39, 23);
            this.btnStop.TabIndex = 60;
            this.btnStop.Text = "Stop";
            this.btnStop.UseVisualStyleBackColor = true;
            // 
            // btnBack
            // 
            this.btnBack.Location = new System.Drawing.Point(2, 1);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(20, 23);
            this.btnBack.TabIndex = 59;
            this.btnBack.Text = "<";
            this.btnBack.UseVisualStyleBackColor = true;
            // 
            // WebBrowser
            // 
            this.WebBrowser.Location = new System.Drawing.Point(3, 42);
            this.WebBrowser.MinimumSize = new System.Drawing.Size(20, 20);
            this.WebBrowser.Name = "WebBrowser";
            this.WebBrowser.Size = new System.Drawing.Size(585, 323);
            this.WebBrowser.TabIndex = 58;
            this.WebBrowser.Url = new System.Uri("http://www.google.com.pk", System.UriKind.Absolute);
            // 
            // InternetBrowsing
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(809, 586);
            this.Controls.Add(this.panelHistory);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panelFooter);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.SubMenu);
            this.Controls.Add(this.MainMenu);
            this.Name = "InternetBrowsing";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Internet Browsing";
            this.Load += new System.EventHandler(this.Users_Load);
            this.SubMenu.ResumeLayout(false);
            this.SubMenu.PerformLayout();
            this.MainMenu.ResumeLayout(false);
            this.MainMenu.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panelFooter.ResumeLayout(false);
            this.panelFooter.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panelHistory.ResumeLayout(false);
            this.panelHistory.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        private System.Windows.Forms.MenuStrip SubMenu;
        private System.Windows.Forms.ToolStripMenuItem menuItemDashboard;
        private System.Windows.Forms.ToolStripMenuItem menuItemManageUsers;
        private System.Windows.Forms.ToolStripMenuItem menuItemManageInventory;
        private System.Windows.Forms.ToolStripMenuItem menuItemManageEmployees;
        private System.Windows.Forms.ToolStripMenuItem menuItemManageSales;
        private System.Windows.Forms.ToolStripMenuItem menuItemExpenses;
        private System.Windows.Forms.MenuStrip MainMenu;
        private System.Windows.Forms.ToolStripMenuItem MenuItemLogout;
        private System.Windows.Forms.ToolStripMenuItem MenuItemHome;
        private System.Windows.Forms.ToolStripMenuItem logoutToolStripMenuItem;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panelFooter;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblManage;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel4;
        #endregion
        private System.Windows.Forms.Panel panelHistory;
        private System.Windows.Forms.Label lblBottom;
        private System.Windows.Forms.Label lblTop;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.Button btnForward;
        private System.Windows.Forms.Button btnHome;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.Button btnGo;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.WebBrowser WebBrowser;

    }
}