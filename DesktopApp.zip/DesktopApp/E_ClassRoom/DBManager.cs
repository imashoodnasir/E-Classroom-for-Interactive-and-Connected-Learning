﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using MySql.Data.MySqlClient;


namespace EClassRoom
{
    public class DBManager
    {
        private MySqlConnection Myconnection;
        private MySqlCommand Mycommand;
        private MySqlDataAdapter myAdapter;
        public int updatecount = 0;
        public string ErrorCode = "";
        public long lastinsertid = 0;
        //private string connectionstring = "server=phpmyadmin.kelp.arvixe.com;user id=demo_inzzoo_user;database=demo_inzzoo_db;Password=demoinzzoopass;Allow User Variables=True;default command timeout=4000";
        private string connectionstring = "server=localhost;user id=root;database=eclassroom;Password=;Allow User Variables=True;default command timeout=4000";
        public DBManager()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        public bool OpenConnection()
        {
            try
            {
                Myconnection = new MySqlConnection(connectionstring);
                Myconnection.Open();
                Mycommand = new MySqlCommand();
                myAdapter = new MySqlDataAdapter();
                Mycommand.Connection = Myconnection;
                return true;
            }
            catch (Exception ex)
            {
                ErrorCode = ex.Message;
                return false;
            }
        }

        public void CloseConnection()
        {
            Myconnection.Close();
            Mycommand = null;
            myAdapter = null;
        }



        public DataTable ExecuteCommandwithReturn(string query)
        {
            try
            {
                OpenConnection();
                Mycommand.CommandText = query;
                myAdapter.SelectCommand = Mycommand;
                DataTable dt = new DataTable();
                myAdapter.Fill(dt);
                CloseConnection();
                return dt;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public bool ExecuteCommandwithNoReturn(string query)
        {
            try
            {
                OpenConnection();
                Mycommand.CommandText = query;
                updatecount = Mycommand.ExecuteNonQuery();
                if (query.StartsWith("insert"))
                    lastinsertid = Mycommand.LastInsertedId;
                CloseConnection();
                if (updatecount != 0)
                {
                    return true;
                }
                else
                    return false;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public bool ExecuteCommandwithNoException(string query)
        {
            try
            {
                OpenConnection();
                Mycommand.CommandText = query;
                updatecount = Mycommand.ExecuteNonQuery();
                CloseConnection();
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public long ExecuteCommandwithLong(string query)
        {
            try
            {
                OpenConnection();
                Mycommand.CommandText = query;
                if (Mycommand.ExecuteNonQuery() != 0)
                {
                    lastinsertid = Mycommand.LastInsertedId;
                    CloseConnection();
                    return lastinsertid;
                }
                else
                    return 0;
            }
            catch (Exception ex)
            {
                return 0;
            }
        }

        public DataTable ReturnDataTable(string Query)
        {
            using (MySqlConnection conApp1 = new MySqlConnection(connectionstring))
            {
                using (MySqlCommand cmd1 = new MySqlCommand(Query))
                {
                    using (MySqlDataAdapter sda1 = new MySqlDataAdapter())
                    {
                        cmd1.Connection = conApp1;
                        sda1.SelectCommand = cmd1;
                        using (DataTable dt = new DataTable())
                        {
                            sda1.Fill(dt);
                            return dt;
                        }
                    }
                }
            }
        }

        public DataSet ReturnDataSet(string Query)
        {
            using (MySqlConnection conApp1 = new MySqlConnection(connectionstring))
            {
                using (MySqlCommand cmd1 = new MySqlCommand(Query))
                {
                    using (MySqlDataAdapter sda1 = new MySqlDataAdapter())
                    {
                        cmd1.Connection = conApp1;
                        sda1.SelectCommand = cmd1;
                        using (DataSet dt = new DataSet())
                        {
                            sda1.Fill(dt);
                            return dt;
                        }
                    }
                }
            }
        }


    }
}
