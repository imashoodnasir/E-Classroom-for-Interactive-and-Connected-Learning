﻿namespace EClassRoom
{
    partial class DashboardTeacher
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DashboardTeacher));
            this.panelFooter = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.MainMenu = new System.Windows.Forms.MenuStrip();
            this.MenuItemLogout = new System.Windows.Forms.ToolStripMenuItem();
            this.logoutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItemHome = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.lblUser = new System.Windows.Forms.Label();
            this.SubMenu = new System.Windows.Forms.MenuStrip();
            this.menuItemDashboard = new System.Windows.Forms.ToolStripMenuItem();
            this.menuItemManageUsers = new System.Windows.Forms.ToolStripMenuItem();
            this.menuItemManageInventory = new System.Windows.Forms.ToolStripMenuItem();
            this.menuItemManageEmployees = new System.Windows.Forms.ToolStripMenuItem();
            this.menuItemManageSales = new System.Windows.Forms.ToolStripMenuItem();
            this.menuItemExpenses = new System.Windows.Forms.ToolStripMenuItem();
            this.panelUsers = new System.Windows.Forms.Panel();
            this.pbUsers = new System.Windows.Forms.PictureBox();
            this.panelInvertory = new System.Windows.Forms.Panel();
            this.pbInventory = new System.Windows.Forms.PictureBox();
            this.panelSales = new System.Windows.Forms.Panel();
            this.pbSales = new System.Windows.Forms.PictureBox();
            this.panelCustomers = new System.Windows.Forms.Panel();
            this.pbCustomers = new System.Windows.Forms.PictureBox();
            this.panelExpenses = new System.Windows.Forms.Panel();
            this.pbExpenses = new System.Windows.Forms.PictureBox();
            this.panelDashboard = new System.Windows.Forms.Panel();
            this.panelFooter.SuspendLayout();
            this.MainMenu.SuspendLayout();
            this.SubMenu.SuspendLayout();
            this.panelUsers.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbUsers)).BeginInit();
            this.panelInvertory.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbInventory)).BeginInit();
            this.panelSales.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbSales)).BeginInit();
            this.panelCustomers.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbCustomers)).BeginInit();
            this.panelExpenses.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbExpenses)).BeginInit();
            this.panelDashboard.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelFooter
            // 
            this.panelFooter.Controls.Add(this.label4);
            this.panelFooter.Location = new System.Drawing.Point(0, 561);
            this.panelFooter.Name = "panelFooter";
            this.panelFooter.Size = new System.Drawing.Size(809, 26);
            this.panelFooter.TabIndex = 23;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(297, 6);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(240, 13);
            this.label4.TabIndex = 30;
            this.label4.Text = "© 2016 Developed By Inzamam Mashood";
            // 
            // MainMenu
            // 
            this.MainMenu.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.MainMenu.GripStyle = System.Windows.Forms.ToolStripGripStyle.Visible;
            this.MainMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MenuItemLogout,
            this.MenuItemHome});
            this.MainMenu.Location = new System.Drawing.Point(0, 0);
            this.MainMenu.Name = "MainMenu";
            this.MainMenu.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.MainMenu.Size = new System.Drawing.Size(809, 24);
            this.MainMenu.TabIndex = 42;
            this.MainMenu.Text = "menuStrip1";
            this.MainMenu.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.MainMenu_ItemClicked);
            // 
            // MenuItemLogout
            // 
            this.MenuItemLogout.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.MenuItemLogout.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.logoutToolStripMenuItem});
            this.MenuItemLogout.Name = "MenuItemLogout";
            this.MenuItemLogout.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.MenuItemLogout.RightToLeftAutoMirrorImage = true;
            this.MenuItemLogout.Size = new System.Drawing.Size(61, 20);
            this.MenuItemLogout.Text = "Options";
            // 
            // logoutToolStripMenuItem
            // 
            this.logoutToolStripMenuItem.Name = "logoutToolStripMenuItem";
            this.logoutToolStripMenuItem.Size = new System.Drawing.Size(112, 22);
            this.logoutToolStripMenuItem.Text = "Logout";
            this.logoutToolStripMenuItem.Click += new System.EventHandler(this.logoutToolStripMenuItem_Click);
            // 
            // MenuItemHome
            // 
            this.MenuItemHome.Name = "MenuItemHome";
            this.MenuItemHome.Size = new System.Drawing.Size(52, 20);
            this.MenuItemHome.Text = "Home";
            this.MenuItemHome.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(342, 4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 17);
            this.label1.TabIndex = 43;
            this.label1.Text = "Welcome ";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblUser
            // 
            this.lblUser.AutoSize = true;
            this.lblUser.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.lblUser.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUser.Location = new System.Drawing.Point(412, 4);
            this.lblUser.Name = "lblUser";
            this.lblUser.Size = new System.Drawing.Size(0, 17);
            this.lblUser.TabIndex = 44;
            this.lblUser.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // SubMenu
            // 
            this.SubMenu.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.SubMenu.GripStyle = System.Windows.Forms.ToolStripGripStyle.Visible;
            this.SubMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuItemDashboard,
            this.menuItemManageUsers,
            this.menuItemManageInventory,
            this.menuItemManageEmployees,
            this.menuItemManageSales,
            this.menuItemExpenses});
            this.SubMenu.Location = new System.Drawing.Point(0, 24);
            this.SubMenu.Name = "SubMenu";
            this.SubMenu.Padding = new System.Windows.Forms.Padding(3, 12, 0, 2);
            this.SubMenu.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.SubMenu.Size = new System.Drawing.Size(809, 33);
            this.SubMenu.TabIndex = 47;
            this.SubMenu.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.SubMenu_ItemClicked);
            // 
            // menuItemDashboard
            // 
            this.menuItemDashboard.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.menuItemDashboard.ForeColor = System.Drawing.Color.White;
            this.menuItemDashboard.Name = "menuItemDashboard";
            this.menuItemDashboard.Size = new System.Drawing.Size(78, 19);
            this.menuItemDashboard.Text = "Dashboard";
            // 
            // menuItemManageUsers
            // 
            this.menuItemManageUsers.Name = "menuItemManageUsers";
            this.menuItemManageUsers.Size = new System.Drawing.Size(96, 19);
            this.menuItemManageUsers.Text = "Manage Notes";
            this.menuItemManageUsers.Click += new System.EventHandler(this.menuItemManageUsers_Click);
            // 
            // menuItemManageInventory
            // 
            this.menuItemManageInventory.Name = "menuItemManageInventory";
            this.menuItemManageInventory.Size = new System.Drawing.Size(126, 19);
            this.menuItemManageInventory.Text = "Manage Documents";
            this.menuItemManageInventory.Click += new System.EventHandler(this.menuItemManageInventory_Click);
            // 
            // menuItemManageEmployees
            // 
            this.menuItemManageEmployees.Name = "menuItemManageEmployees";
            this.menuItemManageEmployees.Size = new System.Drawing.Size(112, 19);
            this.menuItemManageEmployees.Text = "Internet Browsing";
            this.menuItemManageEmployees.Click += new System.EventHandler(this.menuItemManageEmployees_Click);
            // 
            // menuItemManageSales
            // 
            this.menuItemManageSales.Name = "menuItemManageSales";
            this.menuItemManageSales.Size = new System.Drawing.Size(77, 19);
            this.menuItemManageSales.Text = "Quick Quiz";
            this.menuItemManageSales.Click += new System.EventHandler(this.menuItemManageSales_Click);
            // 
            // menuItemExpenses
            // 
            this.menuItemExpenses.Name = "menuItemExpenses";
            this.menuItemExpenses.Size = new System.Drawing.Size(71, 19);
            this.menuItemExpenses.Text = "Start Chat";
            this.menuItemExpenses.Click += new System.EventHandler(this.menuItemExpenses_Click);
            // 
            // panelUsers
            // 
            this.panelUsers.BackColor = System.Drawing.Color.SkyBlue;
            this.panelUsers.Controls.Add(this.pbUsers);
            this.panelUsers.Location = new System.Drawing.Point(105, 23);
            this.panelUsers.Name = "panelUsers";
            this.panelUsers.Size = new System.Drawing.Size(220, 220);
            this.panelUsers.TabIndex = 55;
            // 
            // pbUsers
            // 
            this.pbUsers.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pbUsers.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbUsers.Image = ((System.Drawing.Image)(resources.GetObject("pbUsers.Image")));
            this.pbUsers.Location = new System.Drawing.Point(10, 10);
            this.pbUsers.Name = "pbUsers";
            this.pbUsers.Size = new System.Drawing.Size(200, 200);
            this.pbUsers.TabIndex = 50;
            this.pbUsers.TabStop = false;
            this.pbUsers.Click += new System.EventHandler(this.pbUsers_Click);
            this.pbUsers.MouseLeave += new System.EventHandler(this.pbUsers_MouseLeave);
            this.pbUsers.MouseHover += new System.EventHandler(this.pbUsers_MouseHover);
            // 
            // panelInvertory
            // 
            this.panelInvertory.BackColor = System.Drawing.Color.SkyBlue;
            this.panelInvertory.Controls.Add(this.pbInventory);
            this.panelInvertory.Location = new System.Drawing.Point(456, 23);
            this.panelInvertory.Name = "panelInvertory";
            this.panelInvertory.Size = new System.Drawing.Size(220, 220);
            this.panelInvertory.TabIndex = 56;
            // 
            // pbInventory
            // 
            this.pbInventory.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pbInventory.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbInventory.Image = ((System.Drawing.Image)(resources.GetObject("pbInventory.Image")));
            this.pbInventory.Location = new System.Drawing.Point(10, 10);
            this.pbInventory.Name = "pbInventory";
            this.pbInventory.Size = new System.Drawing.Size(200, 200);
            this.pbInventory.TabIndex = 52;
            this.pbInventory.TabStop = false;
            this.pbInventory.Click += new System.EventHandler(this.pbInventory_Click);
            this.pbInventory.MouseLeave += new System.EventHandler(this.pbInventory_MouseLeave);
            this.pbInventory.MouseHover += new System.EventHandler(this.pbInventory_MouseHover);
            // 
            // panelSales
            // 
            this.panelSales.BackColor = System.Drawing.Color.SkyBlue;
            this.panelSales.Controls.Add(this.pbSales);
            this.panelSales.Location = new System.Drawing.Point(29, 259);
            this.panelSales.Name = "panelSales";
            this.panelSales.Size = new System.Drawing.Size(220, 220);
            this.panelSales.TabIndex = 56;
            // 
            // pbSales
            // 
            this.pbSales.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pbSales.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbSales.Image = ((System.Drawing.Image)(resources.GetObject("pbSales.Image")));
            this.pbSales.Location = new System.Drawing.Point(10, 10);
            this.pbSales.Name = "pbSales";
            this.pbSales.Size = new System.Drawing.Size(200, 200);
            this.pbSales.TabIndex = 51;
            this.pbSales.TabStop = false;
            this.pbSales.Click += new System.EventHandler(this.pbSales_Click);
            this.pbSales.MouseLeave += new System.EventHandler(this.pbSales_MouseLeave);
            this.pbSales.MouseHover += new System.EventHandler(this.pbSales_MouseHover);
            // 
            // panelCustomers
            // 
            this.panelCustomers.BackColor = System.Drawing.Color.SkyBlue;
            this.panelCustomers.Controls.Add(this.pbCustomers);
            this.panelCustomers.Location = new System.Drawing.Point(290, 259);
            this.panelCustomers.Name = "panelCustomers";
            this.panelCustomers.Size = new System.Drawing.Size(220, 220);
            this.panelCustomers.TabIndex = 56;
            // 
            // pbCustomers
            // 
            this.pbCustomers.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pbCustomers.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbCustomers.Image = ((System.Drawing.Image)(resources.GetObject("pbCustomers.Image")));
            this.pbCustomers.Location = new System.Drawing.Point(10, 10);
            this.pbCustomers.Name = "pbCustomers";
            this.pbCustomers.Size = new System.Drawing.Size(200, 200);
            this.pbCustomers.TabIndex = 53;
            this.pbCustomers.TabStop = false;
            this.pbCustomers.Click += new System.EventHandler(this.pbCustomers_Click);
            this.pbCustomers.MouseLeave += new System.EventHandler(this.pbCustomers_MouseLeave);
            this.pbCustomers.MouseHover += new System.EventHandler(this.pbCustomers_MouseHover);
            // 
            // panelExpenses
            // 
            this.panelExpenses.BackColor = System.Drawing.Color.SkyBlue;
            this.panelExpenses.Controls.Add(this.pbExpenses);
            this.panelExpenses.Location = new System.Drawing.Point(541, 259);
            this.panelExpenses.Name = "panelExpenses";
            this.panelExpenses.Size = new System.Drawing.Size(220, 220);
            this.panelExpenses.TabIndex = 58;
            // 
            // pbExpenses
            // 
            this.pbExpenses.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pbExpenses.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbExpenses.Image = ((System.Drawing.Image)(resources.GetObject("pbExpenses.Image")));
            this.pbExpenses.Location = new System.Drawing.Point(10, 10);
            this.pbExpenses.Name = "pbExpenses";
            this.pbExpenses.Size = new System.Drawing.Size(200, 200);
            this.pbExpenses.TabIndex = 55;
            this.pbExpenses.TabStop = false;
            this.pbExpenses.Click += new System.EventHandler(this.pbExpenses_Click);
            this.pbExpenses.MouseLeave += new System.EventHandler(this.pbExpenses_MouseLeave);
            this.pbExpenses.MouseHover += new System.EventHandler(this.pbExpenses_MouseHover);
            // 
            // panelDashboard
            // 
            this.panelDashboard.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panelDashboard.Controls.Add(this.panelExpenses);
            this.panelDashboard.Controls.Add(this.panelCustomers);
            this.panelDashboard.Controls.Add(this.panelSales);
            this.panelDashboard.Controls.Add(this.panelInvertory);
            this.panelDashboard.Controls.Add(this.panelUsers);
            this.panelDashboard.Location = new System.Drawing.Point(0, 60);
            this.panelDashboard.Name = "panelDashboard";
            this.panelDashboard.Size = new System.Drawing.Size(809, 504);
            this.panelDashboard.TabIndex = 48;
            // 
            // DashboardTeacher
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(809, 586);
            this.Controls.Add(this.SubMenu);
            this.Controls.Add(this.lblUser);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.MainMenu);
            this.Controls.Add(this.panelFooter);
            this.Controls.Add(this.panelDashboard);
            this.MaximizeBox = false;
            this.Name = "DashboardTeacher";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Teacher\'s Dashboard";
            this.Load += new System.EventHandler(this.Dashboard_Load);
            this.panelFooter.ResumeLayout(false);
            this.panelFooter.PerformLayout();
            this.MainMenu.ResumeLayout(false);
            this.MainMenu.PerformLayout();
            this.SubMenu.ResumeLayout(false);
            this.SubMenu.PerformLayout();
            this.panelUsers.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbUsers)).EndInit();
            this.panelInvertory.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbInventory)).EndInit();
            this.panelSales.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbSales)).EndInit();
            this.panelCustomers.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbCustomers)).EndInit();
            this.panelExpenses.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbExpenses)).EndInit();
            this.panelDashboard.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private System.Windows.Forms.Panel panelFooter;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.MenuStrip MainMenu;
        private System.Windows.Forms.ToolStripMenuItem MenuItemHome;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblUser;
        private System.Windows.Forms.MenuStrip SubMenu;
        private System.Windows.Forms.ToolStripMenuItem menuItemDashboard;
        private System.Windows.Forms.ToolStripMenuItem menuItemManageUsers;
        private System.Windows.Forms.ToolStripMenuItem menuItemManageInventory;
        private System.Windows.Forms.ToolStripMenuItem menuItemManageEmployees;
        private System.Windows.Forms.ToolStripMenuItem menuItemManageSales;
        private System.Windows.Forms.ToolStripMenuItem menuItemExpenses;
        private System.Windows.Forms.Panel panelUsers;
        private System.Windows.Forms.PictureBox pbUsers;
        private System.Windows.Forms.Panel panelInvertory;
        private System.Windows.Forms.PictureBox pbInventory;
        private System.Windows.Forms.Panel panelSales;
        private System.Windows.Forms.PictureBox pbSales;
        private System.Windows.Forms.Panel panelCustomers;
        private System.Windows.Forms.PictureBox pbCustomers;
        private System.Windows.Forms.Panel panelExpenses;
        private System.Windows.Forms.PictureBox pbExpenses;
        private System.Windows.Forms.Panel panelDashboard;

        #endregion

        private System.Windows.Forms.ToolStripMenuItem MenuItemLogout;
        private System.Windows.Forms.ToolStripMenuItem logoutToolStripMenuItem;
    }
}