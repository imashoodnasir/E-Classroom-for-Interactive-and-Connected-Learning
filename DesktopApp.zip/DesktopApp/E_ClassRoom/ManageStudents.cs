﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EClassRoom
{
    public partial class ManageStudents : Form
    {
        public ManageStudents()
        {
            InitializeComponent();
        }
        private void lblManage_MouseHover(object sender, EventArgs e)
        {
            lblManage.ForeColor = Color.Red;
        }

        private void lblManage_MouseLeave(object sender, EventArgs e)
        {
            lblManage.ForeColor = Color.Black;
        }

        private void lblManage_Click(object sender, EventArgs e)
        {
            lblManage.Font = new Font("Microsoft Sans Serif", 9, FontStyle.Bold);
            panelManageNotes.Visible = true;
            lblTitle.Text = "Manage Documents";
        }

        private void Users_Load(object sender, EventArgs e)
        {
            panelManageNotes.Visible = true;
        }

        private void menuItemManageUsers_Click(object sender, EventArgs e)
        {
            ManageNotesTeacher mn = new ManageNotesTeacher();
            mn.FormClosed += new FormClosedEventHandler(db_FormClosed);
            mn.Show();
            this.Hide();
        }

        private void db_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Close();
        }

        private void menuItemDashboard_Click(object sender, EventArgs e)
        {
            DashboardTeacher db = new DashboardTeacher();
            db.FormClosed += new FormClosedEventHandler(db_FormClosed);
            db.Show();
            this.Hide();
        }

        private void MenuItemHome_Click(object sender, EventArgs e)
        {
            MainForm mf = new MainForm();
            mf.FormClosed += new FormClosedEventHandler(db_FormClosed);
            mf.Show();
            this.Hide();
        }

        private void menuItemManageEmployees_Click(object sender, EventArgs e)
        {
            InternetBrowsingTeacher ib = new InternetBrowsingTeacher();
            ib.FormClosed += new FormClosedEventHandler(db_FormClosed);
            ib.Show();
            this.Hide();
        }

        private void menuItemManageSales_Click(object sender, EventArgs e)
        {
            QuickQuiz aq = new QuickQuiz();
            aq.FormClosed += new FormClosedEventHandler(db_FormClosed);
            aq.Show();
            this.Hide();
        }

        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MainForm mf = new MainForm();
            mf.FormClosed += new FormClosedEventHandler(db_FormClosed);
            mf.Show();
            this.Hide();
        }

        private void menuItemExpenses_Click(object sender, EventArgs e)
        {
            StartChat aq = new StartChat();
            aq.FormClosed += new FormClosedEventHandler(db_FormClosed);
            aq.Show();
            this.Hide();
        }

        private void menuItemManageInventory_Click(object sender, EventArgs e)
        {
            ManageDocumentsTeacher aq = new ManageDocumentsTeacher();
            aq.FormClosed += new FormClosedEventHandler(db_FormClosed);
            aq.Show();
            this.Hide();
        }
    }
}
