﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EClassRoom
{
    class Global
    {
        private static string userId;

        static Global()
        {
        }

        public static string UserId
        {
            get
            {
                return (userId);
            }
            set
            {
                userId = value;
            }
        }
    }
}
