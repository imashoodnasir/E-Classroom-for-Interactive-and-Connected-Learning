﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Windows.Forms;

namespace EClassRoom
{
    public partial class ManageNotesTeacher : Form
    {
        public ManageNotesTeacher()
        {
            InitializeComponent();
        }
        DBManager objDBManager = new DBManager();

        private void lblManage_MouseHover(object sender, EventArgs e)
        {
            lblManage.ForeColor = Color.Red;
        }

        private void lblManage_MouseLeave(object sender, EventArgs e)
        {
            lblManage.ForeColor = Color.Black;
        }

        private void lblManage_Click(object sender, EventArgs e)
        {
            lblManage.Font = new Font("Microsoft Sans Serif", 9, FontStyle.Bold);
            lblCreateNotes.Font = new Font("Microsoft Sans Serif", 9, FontStyle.Regular);
            panelCreateNotes.Visible = false;
            panelManageNotes.Visible = true;
            lblTitle.Text = "Manage Notes";
        }

        private void Users_Load(object sender, EventArgs e)
        {
            panelManageNotes.Visible = true;
            panelCreateNotes.Visible = false;
            loadNotes();
            DataTable dt = objDBManager.ReturnDataTable("select * from tblsubjects where IsActive = 'Yes'");
            comboBox1.DataSource = dt;
            comboBox1.DisplayMember = "Subject_title";
            comboBox1.ValueMember = "ID";
        }

        private void lblCreateNotes_MouseHover(object sender, EventArgs e)
        {
            lblCreateNotes.ForeColor = Color.Red;
        }

        private void lblCreateNotes_MouseLeave(object sender, EventArgs e)
        {
            lblCreateNotes.ForeColor = Color.Black;
        }

        private void lblCreateNotes_Click(object sender, EventArgs e)
        {
            lblCreateNotes.Font = new Font("Microsoft Sans Serif", 9, FontStyle.Bold);
            lblManage.Font = new Font("Microsoft Sans Serif", 9, FontStyle.Regular);
            panelCreateNotes.Visible = true;
            panelManageNotes.Visible = false;
            lblTitle.Text = "Create New Notes";
            richTextBox1.Text = "";
            txtNotesTitle.Text = "";
            comboBox1.SelectedIndex = 0;
        }

        private void menuItemDashboard_Click(object sender, EventArgs e)
        {
            DashboardTeacher db = new DashboardTeacher();
            db.FormClosed += new FormClosedEventHandler(db_FormClosed);
            db.Show();
            this.Hide();
        }

        private void db_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Close();
        }

        private void menuItemManageInventory_Click(object sender, EventArgs e)
        {
            ManageDocumentsTeacher md = new ManageDocumentsTeacher();
            md.FormClosed += new FormClosedEventHandler(db_FormClosed);
            md.Show();
            this.Hide();
        }

        private void menuItemManageEmployees_Click(object sender, EventArgs e)
        {
            InternetBrowsingTeacher ib = new InternetBrowsingTeacher();
            ib.FormClosed += new FormClosedEventHandler(db_FormClosed);
            ib.Show();
            this.Hide();
        }

        private void menuItemManageSales_Click(object sender, EventArgs e)
        {
            QuickQuiz aq = new QuickQuiz();
            aq.FormClosed += new FormClosedEventHandler(db_FormClosed);
            aq.Show();
            this.Hide();
        }

        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MainForm mf = new MainForm();
            mf.FormClosed += new FormClosedEventHandler(db_FormClosed);
            mf.Show();
            this.Hide();
        }

        private void menuItemExpenses_Click(object sender, EventArgs e)
        {
            StartChat aq = new StartChat();
            aq.FormClosed += new FormClosedEventHandler(db_FormClosed);
            aq.Show();
            this.Hide();
        }

        private void manageStudentsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ManageStudents aq = new ManageStudents();
            aq.FormClosed += new FormClosedEventHandler(db_FormClosed);
            aq.Show();
            this.Hide();
        }

        private void btnSaveNotes_Click(object sender, EventArgs e)
        {
            if (listBoxNotes.SelectedIndex != -1)
            {
                string id = listBoxNotes.Items[listBoxNotes.SelectedIndex].ToString().Split(':')[0];
                string query = "Update tblnotes set NotesContent = '" + Uri.EscapeUriString(richTextBox1.Text) + "' , NotesTitle = '" + txtNotesTitle.Text + "',Subject_Id = '" + comboBox1.SelectedValue + "'  where ID = " + id;
                objDBManager.ExecuteCommandwithNoReturn(query);
                richTextBox1.Text = "";
                txtNotesTitle.Text = "";
            }
            else
            {
                string query = "Insert into tblnotes(NotesContent,NotesTitle, Subject_Id,User_Id,UploadDate) Values( '" + Uri.EscapeUriString(richTextBox1.Text) + "','" + txtNotesTitle.Text + "','" + comboBox1.SelectedValue + "','" + Global.UserId + "','" + DateTime.Now.ToString("dd-MM-yyyy hh:mm:ss") + "') ";
                objDBManager.ExecuteCommandwithNoReturn(query);
                loadNotes();
            }
            panelManageNotes.Visible = true;
            panelCreateNotes.Visible = false;
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            panelManageNotes.Visible = false;
            panelCreateNotes.Visible = true;
            string id = listBoxNotes.Items[listBoxNotes.SelectedIndex].ToString().Split(':')[0];
            DBManager objDBManager = new DBManager();
            DataTable dt = objDBManager.ReturnDataTable("select * from tblnotes where ID = " + id);
            if (dt.Rows.Count > 0)
            {
                richTextBox1.Text = HttpUtility.UrlDecode(dt.Rows[0]["NotesContent"].ToString());
                txtNotesTitle.Text = dt.Rows[0]["NotesTitle"].ToString();
                comboBox1.SelectedValue = dt.Rows[0]["Subject_ID"].ToString();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (listBoxNotes.SelectedIndex != -1)
            {
                string id = listBoxNotes.Items[listBoxNotes.SelectedIndex].ToString().Split(':')[0];
                string query = "Delete from tblnotes where ID = " + id;
                objDBManager.ExecuteCommandwithNoReturn(query);
                loadNotes();
            }
        }
        private void loadNotes()
        {
            listBoxNotes.Items.Clear();
            DataTable dt = objDBManager.ReturnDataTable("select * from tblnotes where User_ID ='" + Global.UserId + "'");
            for (int a = 0; a < dt.Rows.Count; a++)
            {
                listBoxNotes.Items.Insert(a, dt.Rows[a]["ID"].ToString() + ": " + dt.Rows[a]["NotesTitle"].ToString());
            }
            lblTotal.Text = "Total Notes: " + dt.Rows.Count.ToString();
        }
    }
}
