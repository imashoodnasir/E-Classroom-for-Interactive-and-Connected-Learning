﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EClassRoom
{
   
    public partial class StartChat : Form
    {
        private delegate void UpdateStatusCallback(string strMessage);
        public StartChat()
        {
            InitializeComponent();
        }

        private void lblManage_MouseHover(object sender, EventArgs e)
        {
            lblManage.ForeColor = Color.Red;
        }

        private void lblManage_MouseLeave(object sender, EventArgs e)
        {
            lblManage.ForeColor = Color.Black;
        }

        private void lblManage_Click(object sender, EventArgs e)
        {
            lblManage.Font = new Font("Microsoft Sans Serif", 9, FontStyle.Bold);
            panelInternetBrowsing.Visible = true;

            lblTitle.Text = "Current Quiz";
        }

        private void Users_Load(object sender, EventArgs e)
        {
            panelInternetBrowsing.Visible = true;
        }

        private void menuItemManageUsers_Click(object sender, EventArgs e)
        {
            ManageNotesTeacher mn = new ManageNotesTeacher();
            mn.FormClosed += new FormClosedEventHandler(db_FormClosed);
            mn.Show();
            this.Hide();
        }

        private void db_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Close();
        }

        private void menuItemDashboard_Click(object sender, EventArgs e)
        {
            DashboardTeacher db = new DashboardTeacher();
            db.FormClosed += new FormClosedEventHandler(db_FormClosed);
            db.Show();
            this.Hide();
        }

        private void MenuItemHome_Click(object sender, EventArgs e)
        {
            MainForm mf = new MainForm();
            mf.FormClosed += new FormClosedEventHandler(db_FormClosed);
            mf.Show();
            this.Hide();
        }

        private void lblTotal_Click(object sender, EventArgs e)
        {
            lblManage.Font = new Font("Microsoft Sans Serif", 9, FontStyle.Regular);
            panelInternetBrowsing.Visible = false;

            lblTitle.Text = "Available Quizes";
        }

        private void menuItemManageInventory_Click(object sender, EventArgs e)
        {
            ManageDocumentsTeacher md = new ManageDocumentsTeacher();
            md.FormClosed += new FormClosedEventHandler(db_FormClosed);
            md.Show();
            this.Hide();
        }

        private void menuItemManageEmployees_Click(object sender, EventArgs e)
        {
            InternetBrowsingTeacher ib = new InternetBrowsingTeacher();
            ib.FormClosed += new FormClosedEventHandler(db_FormClosed);
            ib.Show();
            this.Hide();
        }

        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MainForm mf = new MainForm();
            mf.FormClosed += new FormClosedEventHandler(db_FormClosed);
            mf.Show();
            this.Hide();
        }

        private void menuItemManageSales_Click(object sender, EventArgs e)
        {
            QuickQuiz aq = new QuickQuiz();
            aq.FormClosed += new FormClosedEventHandler(db_FormClosed);
            aq.Show();
            this.Hide();
        }

        private void manageStudentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ManageStudents aq = new ManageStudents();
            aq.FormClosed += new FormClosedEventHandler(db_FormClosed);
            aq.Show();
            this.Hide();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            IPAddress ipAddr = IPAddress.Parse(txtServerIP.Text);
            ChatServer mainServer = new ChatServer(ipAddr);
            ChatServer.StatusChanged += new StatusChangedEventHandler(mainServer_StatusChanged);
            mainServer.StartListening();
            txtLog.AppendText("Monitoring for connections...\r\n");
        }

        public void mainServer_StatusChanged(object sender, StatusChangedEventArgs e)
        {
            this.Invoke(new UpdateStatusCallback(this.UpdateStatus), new object[] { e.EventMessage });
        }

        private void UpdateStatus(string strMessage)
        {
            txtLog.AppendText(strMessage + "\r\n");
        }
    }
}
