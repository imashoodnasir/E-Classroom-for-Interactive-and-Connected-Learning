﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;
using System.Threading;

namespace EClassRoom
{
    public partial class LiveChat : Form
    {
        private string UserName = "Unknown";
        private StreamWriter swSender;
        private StreamReader srReceiver;
        private TcpClient tcpServer;

        private delegate void UpdateLogCallback(string strMessage);

        private delegate void CloseConnectionCallback(string strReason);
        private Thread thrMessaging;
        private IPAddress ipAddr;
        private bool Connected;
        public LiveChat()
        {
            Application.ApplicationExit += new EventHandler(OnApplicationExit);
            InitializeComponent();
        }

        public void OnApplicationExit(object sender, EventArgs e)
        {
            if (Connected == true)
            {
                Connected = false;
                swSender.Close();
                srReceiver.Close();
                tcpServer.Close();
            }
        }

        private void lblManage_MouseHover(object sender, EventArgs e)
        {
            lblManage.ForeColor = Color.Red;
        }

        private void lblManage_MouseLeave(object sender, EventArgs e)
        {
            lblManage.ForeColor = Color.Black;
        }

        private void lblManage_Click(object sender, EventArgs e)
        {
            lblManage.Font = new Font("Microsoft Sans Serif", 9, FontStyle.Bold);
            panelInternetBrowsing.Visible = true;

            lblTitle.Text = "Current Quiz";
        }

        private void Users_Load(object sender, EventArgs e)
        {
            panelInternetBrowsing.Visible = true;
        }

        private void menuItemManageUsers_Click(object sender, EventArgs e)
        {
            ManageNotes mn = new ManageNotes();
            mn.FormClosed += new FormClosedEventHandler(db_FormClosed);
            mn.Show();
            this.Hide();
        }

        private void db_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Close();
        }

        private void menuItemDashboard_Click(object sender, EventArgs e)
        {
            Dashboard db = new Dashboard();
            db.FormClosed += new FormClosedEventHandler(db_FormClosed);
            db.Show();
            this.Hide();
        }

        private void MenuItemHome_Click(object sender, EventArgs e)
        {
            MainForm mf = new MainForm();
            mf.FormClosed += new FormClosedEventHandler(db_FormClosed);
            mf.Show();
            this.Hide();
        }

        private void lblTotal_Click(object sender, EventArgs e)
        {
            lblManage.Font = new Font("Microsoft Sans Serif", 9, FontStyle.Regular);
            panelInternetBrowsing.Visible = false;

            lblTitle.Text = "Available Quizes";
        }

        private void menuItemManageInventory_Click(object sender, EventArgs e)
        {
            ManageDocuments md = new ManageDocuments();
            md.FormClosed += new FormClosedEventHandler(db_FormClosed);
            md.Show();
            this.Hide();
        }

        private void menuItemManageEmployees_Click(object sender, EventArgs e)
        {
            InternetBrowsing ib = new InternetBrowsing();
            ib.FormClosed += new FormClosedEventHandler(db_FormClosed);
            ib.Show();
            this.Hide();
        }

        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MainForm mf = new MainForm();
            mf.FormClosed += new FormClosedEventHandler(db_FormClosed);
            mf.Show();
            this.Hide();
        }

        private void menuItemManageSales_Click(object sender, EventArgs e)
        {
            AvailableQuiz aq = new AvailableQuiz();
            aq.FormClosed += new FormClosedEventHandler(db_FormClosed);
            aq.Show();
            this.Hide();
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            if (Connected == false)
            {
                InitializeConnection();
            }
            else
            {
                CloseConnection("Disconnected at user's request.");
                Connected = false;

            }
        }

        private void InitializeConnection()
        {
            ipAddr = IPAddress.Parse(txtServerIP.Text);
            tcpServer = new TcpClient();
            tcpServer.Connect(ipAddr, 1986);
            Connected = true;
            UserName = txtUsername.Text;
            txtServerIP.Enabled = false;
            txtUsername.Enabled = false;
            txtNewMessage.Enabled = true;
            btnSend.Enabled = true;
            btnConnect.Text = "Disconnect";
            swSender = new StreamWriter(tcpServer.GetStream());
            swSender.WriteLine(txtUsername.Text);
            swSender.Flush();
            thrMessaging = new Thread(new ThreadStart(ReceiveMessages));
            thrMessaging.Start();
        }
        private void ReceiveMessages()
        {
            srReceiver = new StreamReader(tcpServer.GetStream());
            string ConResponse = srReceiver.ReadLine();
            while (Connected)
            {
                this.Invoke(new UpdateLogCallback(this.UpdateLog), new object[] { srReceiver.ReadLine() });
            }
            if (ConResponse[0] == '1')
            {
                this.Invoke(new UpdateLogCallback(this.UpdateLog), new object[] { "Connected Successfully!" });
            }
            else
            {
                string Reason = "Not Connected: ";
                Reason += ConResponse.Substring(2, ConResponse.Length - 2);
                this.Invoke(new CloseConnectionCallback(this.CloseConnection), new object[] { Reason });
                Connected = false;
                return;
            }
        }

        private void UpdateLog(string strMessage)
        {
            txtLog.AppendText(strMessage + "\r\n");
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            SendMessage();
        }

        private void txtNewMessage_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                SendMessage();
            }
        }

        private void SendMessage()
        {
            if (txtNewMessage.Lines.Length >= 1)
            {
                swSender.WriteLine(txtNewMessage.Text);
                swSender.Flush();
                txtNewMessage.Lines = null;
            }
            txtNewMessage.Text = "";
        }

        private void CloseConnection(string Reason)
        {
            txtLog.AppendText(Reason + "\r\n");
            txtServerIP.Enabled = true;
            txtUsername.Enabled = true;
            txtNewMessage.Enabled = false;
            btnSend.Enabled = false;
            btnConnect.Text = "Connect";
            Connected = false;
            swSender.Close();
            srReceiver.Close();
            tcpServer.Close();
        }
    }
}
