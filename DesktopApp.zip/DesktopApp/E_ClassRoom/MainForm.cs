﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace EClassRoom
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }
        DBManager objDBManager = new DBManager();

        private void Form1_Load(object sender, EventArgs e)
        {
            ResetImageLocation();
            SetHeight();
            MainForm mf = new MainForm();
            mf.Text = "® SCOSM | Main";
        }

        private void pictureBox1_MouseHover(object sender, EventArgs e)
        {
            pictureBox1.Width = 600;
            pictureBox2.Width = 38;
            pictureBox3.Width = 38;
            pictureBox4.Width = 38;
            pictureBox5.Width = 38;
            pictureBox6.Width = 38;
            SetHeight();
            pictureBox2.Location = new Point (610, 27);
            pictureBox3.Location = new Point(648, 27);
            pictureBox4.Location = new Point(686, 27);
            pictureBox5.Location = new Point(724, 27);
            pictureBox6.Location = new Point(762, 27);
        }

        private void pictureBox2_MouseHover(object sender, EventArgs e)
        {
            pictureBox1.Width = 38;
            pictureBox2.Width = 600;
            pictureBox3.Width = 38;
            pictureBox4.Width = 38;
            pictureBox5.Width = 38;
            pictureBox6.Width = 38;
            SetHeight();
            pictureBox1.Location = new Point(10, 27);
            pictureBox2.Location = new Point(48, 27);
            pictureBox3.Location = new Point(648, 27);
            pictureBox4.Location = new Point(686, 27);
            pictureBox5.Location = new Point(724, 27);
            pictureBox6.Location = new Point(762, 27);
        }

        private void pictureBox3_MouseHover(object sender, EventArgs e)
        {
            pictureBox1.Width = 38;
            pictureBox2.Width = 38;
            pictureBox3.Width = 600;
            pictureBox4.Width = 38;
            pictureBox5.Width = 38;
            pictureBox6.Width = 38;
            SetHeight();
            pictureBox1.Location = new Point(10, 27);
            pictureBox2.Location = new Point(48, 27);
            pictureBox3.Location = new Point(86, 27);
            pictureBox4.Location = new Point(686, 27);
            pictureBox5.Location = new Point(724, 27);
            pictureBox6.Location = new Point(762, 27);
        }

        private void pictureBox4_MouseHover(object sender, EventArgs e)
        {
            pictureBox1.Width = 38;
            pictureBox2.Width = 38;
            pictureBox3.Width = 38;
            pictureBox4.Width = 600;
            pictureBox5.Width = 38;
            pictureBox6.Width = 38;
            SetHeight();
            pictureBox1.Location = new Point(10, 27);
            pictureBox2.Location = new Point(48, 27);
            pictureBox3.Location = new Point(86, 27);
            pictureBox4.Location = new Point(124, 27);
            pictureBox5.Location = new Point(724, 27);
            pictureBox6.Location = new Point(762, 27);
        }

        private void pictureBox5_MouseHover(object sender, EventArgs e)
        {
            pictureBox1.Width = 38;
            pictureBox2.Width = 38;
            pictureBox3.Width = 38;
            pictureBox4.Width = 38;
            pictureBox5.Width = 600;
            pictureBox6.Width = 38;
            SetHeight();
            pictureBox1.Location = new Point(10, 27);
            pictureBox2.Location = new Point(48, 27);
            pictureBox3.Location = new Point(86, 27);
            pictureBox4.Location = new Point(124, 27);
            pictureBox5.Location = new Point(162, 27);
            pictureBox6.Location = new Point(762, 27);
        }

        private void pictureBox6_MouseHover(object sender, EventArgs e)
        {
            
        }

        public void ResetImageLocation()
        {
            pictureBox1.Width = 140;
            pictureBox2.Width = 130;
            pictureBox3.Width = 130;
            pictureBox4.Width = 130;
            pictureBox5.Width = 130;
            pictureBox6.Width = 130;
            pictureBox1.Location = new Point(10, 27);
            pictureBox2.Location = new Point(150, 27);
            pictureBox3.Location = new Point(280, 27);
            pictureBox4.Location = new Point(410, 27);
            pictureBox5.Location = new Point(540, 27);
            pictureBox6.Location = new Point(670, 27);

        }

        public void SetHeight()
        {
            pictureBox1.Height = 295;
            pictureBox2.Height = 295;
            pictureBox3.Height = 295;
            pictureBox4.Height = 295;
            pictureBox5.Height = 295;
            pictureBox6.Height = 295;
        }

        private void Form1_MouseLeave(object sender, EventArgs e)
        {
            ResetImageLocation();
            
        }

        private void MenuItemHome_Click(object sender, EventArgs e)
        {
            panelLogin.Visible = true;
        }

        private void MenuItemAbout_Click(object sender, EventArgs e)
        {
            panelLogin.Visible = false;
        }

        private void MenuItemPolicy_Click(object sender, EventArgs e)
        {
            panelLogin.Visible = false;
        }

        private void MenuItemContact_Click(object sender, EventArgs e)
        {
            panelLogin.Visible = false;
        }
        private void btnLogin_Click(object sender, EventArgs e)
        {
            string query = "Select * from tblusers where Username = '" + txtUsername.Text + "' and Password = '" + txtPassword.Text + "' and isAccepted = 'Yes' and isBlocked = 'No' ";
            DataTable dt = objDBManager.ReturnDataTable(query);
            if (dt.Rows.Count > 0)
            {
                string userId = dt.Rows[0]["User_ID"].ToString();
                string role = dt.Rows[0]["Role"].ToString();
                Global.UserId = userId;
                //Application.Current.Resources["UserId"] = userId;
                if (role == "2")
                {
                    DashboardTeacher db = new DashboardTeacher();
                    db.FormClosed += new FormClosedEventHandler(db_FormClosed);
                    db.Show();
                    this.Hide();
                }
                else if (role == "3")
                {
                    Dashboard db = new Dashboard();
                    db.FormClosed += new FormClosedEventHandler(db_FormClosed);
                    db.Show();
                    this.Hide();
                }
            }
            
        }

        private void db_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Close();
        }

        private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
        {

        }

        private void pictureBox6_MouseEnter(object sender, EventArgs e)
        {
            pictureBox1.Width = 38;
            pictureBox2.Width = 38;
            pictureBox3.Width = 38;
            pictureBox4.Width = 38;
            pictureBox5.Width = 38;
            pictureBox6.Width = 600;
            SetHeight();
            pictureBox1.Location = new Point(10, 27);
            pictureBox2.Location = new Point(48, 27);
            pictureBox3.Location = new Point(86, 27);
            pictureBox4.Location = new Point(124, 27);
            pictureBox5.Location = new Point(162, 27);
            pictureBox6.Location = new Point(200, 27);
        }
    }
}
