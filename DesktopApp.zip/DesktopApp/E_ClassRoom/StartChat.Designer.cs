﻿namespace EClassRoom
{
    partial class StartChat
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(StartChat));
            this.SubMenu = new System.Windows.Forms.MenuStrip();
            this.menuItemDashboard = new System.Windows.Forms.ToolStripMenuItem();
            this.menuItemManageUsers = new System.Windows.Forms.ToolStripMenuItem();
            this.menuItemManageInventory = new System.Windows.Forms.ToolStripMenuItem();
            this.menuItemManageEmployees = new System.Windows.Forms.ToolStripMenuItem();
            this.menuItemManageSales = new System.Windows.Forms.ToolStripMenuItem();
            this.menuItemExpenses = new System.Windows.Forms.ToolStripMenuItem();
            this.MainMenu = new System.Windows.Forms.MenuStrip();
            this.MenuItemLogout = new System.Windows.Forms.ToolStripMenuItem();
            this.logoutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItemHome = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.lblManage = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.panelFooter = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lblTitle = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panelInternetBrowsing = new System.Windows.Forms.Panel();
            this.txtLog = new System.Windows.Forms.TextBox();
            this.txtServerIP = new System.Windows.Forms.TextBox();
            this.btnStart = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.SubMenu.SuspendLayout();
            this.MainMenu.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panelFooter.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panelInternetBrowsing.SuspendLayout();
            this.SuspendLayout();
            // 
            // SubMenu
            // 
            this.SubMenu.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.SubMenu.GripStyle = System.Windows.Forms.ToolStripGripStyle.Visible;
            this.SubMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuItemDashboard,
            this.menuItemManageUsers,
            this.menuItemManageInventory,
            this.menuItemManageEmployees,
            this.menuItemManageSales,
            this.menuItemExpenses});
            this.SubMenu.Location = new System.Drawing.Point(0, 24);
            this.SubMenu.Name = "SubMenu";
            this.SubMenu.Padding = new System.Windows.Forms.Padding(3, 12, 0, 2);
            this.SubMenu.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.SubMenu.Size = new System.Drawing.Size(809, 33);
            this.SubMenu.TabIndex = 49;
            this.SubMenu.Text = "menuStrip2";
            // 
            // menuItemDashboard
            // 
            this.menuItemDashboard.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.menuItemDashboard.ForeColor = System.Drawing.Color.Black;
            this.menuItemDashboard.Name = "menuItemDashboard";
            this.menuItemDashboard.Size = new System.Drawing.Size(76, 19);
            this.menuItemDashboard.Text = "Dashboard";
            this.menuItemDashboard.Click += new System.EventHandler(this.menuItemDashboard_Click);
            // 
            // menuItemManageUsers
            // 
            this.menuItemManageUsers.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.menuItemManageUsers.ForeColor = System.Drawing.Color.Black;
            this.menuItemManageUsers.Name = "menuItemManageUsers";
            this.menuItemManageUsers.Size = new System.Drawing.Size(96, 19);
            this.menuItemManageUsers.Text = "Manage Notes";
            this.menuItemManageUsers.Click += new System.EventHandler(this.menuItemManageUsers_Click);
            // 
            // menuItemManageInventory
            // 
            this.menuItemManageInventory.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.menuItemManageInventory.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.menuItemManageInventory.Name = "menuItemManageInventory";
            this.menuItemManageInventory.Size = new System.Drawing.Size(126, 19);
            this.menuItemManageInventory.Text = "Manage Documents";
            this.menuItemManageInventory.Click += new System.EventHandler(this.menuItemManageInventory_Click);
            // 
            // menuItemManageEmployees
            // 
            this.menuItemManageEmployees.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.menuItemManageEmployees.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.menuItemManageEmployees.Name = "menuItemManageEmployees";
            this.menuItemManageEmployees.Size = new System.Drawing.Size(112, 19);
            this.menuItemManageEmployees.Text = "Internet Browsing";
            this.menuItemManageEmployees.Click += new System.EventHandler(this.menuItemManageEmployees_Click);
            // 
            // menuItemManageSales
            // 
            this.menuItemManageSales.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.menuItemManageSales.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.menuItemManageSales.Name = "menuItemManageSales";
            this.menuItemManageSales.Size = new System.Drawing.Size(77, 19);
            this.menuItemManageSales.Text = "Quick Quiz";
            this.menuItemManageSales.Click += new System.EventHandler(this.menuItemManageSales_Click);
            // 
            // menuItemExpenses
            // 
            this.menuItemExpenses.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.menuItemExpenses.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.menuItemExpenses.Name = "menuItemExpenses";
            this.menuItemExpenses.Size = new System.Drawing.Size(75, 19);
            this.menuItemExpenses.Text = "Start Chat";
            // 
            // MainMenu
            // 
            this.MainMenu.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.MainMenu.GripStyle = System.Windows.Forms.ToolStripGripStyle.Visible;
            this.MainMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MenuItemLogout,
            this.MenuItemHome});
            this.MainMenu.Location = new System.Drawing.Point(0, 0);
            this.MainMenu.Name = "MainMenu";
            this.MainMenu.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.MainMenu.Size = new System.Drawing.Size(809, 24);
            this.MainMenu.TabIndex = 48;
            this.MainMenu.Text = "menuStrip1";
            // 
            // MenuItemLogout
            // 
            this.MenuItemLogout.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.MenuItemLogout.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.MenuItemLogout.Checked = true;
            this.MenuItemLogout.CheckState = System.Windows.Forms.CheckState.Checked;
            this.MenuItemLogout.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.logoutToolStripMenuItem});
            this.MenuItemLogout.Name = "MenuItemLogout";
            this.MenuItemLogout.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.MenuItemLogout.RightToLeftAutoMirrorImage = true;
            this.MenuItemLogout.Size = new System.Drawing.Size(61, 20);
            this.MenuItemLogout.Text = "Options";
            // 
            // logoutToolStripMenuItem
            // 
            this.logoutToolStripMenuItem.Name = "logoutToolStripMenuItem";
            this.logoutToolStripMenuItem.Size = new System.Drawing.Size(112, 22);
            this.logoutToolStripMenuItem.Text = "Logout";
            this.logoutToolStripMenuItem.Click += new System.EventHandler(this.logoutToolStripMenuItem_Click);
            // 
            // MenuItemHome
            // 
            this.MenuItemHome.Name = "MenuItemHome";
            this.MenuItemHome.Size = new System.Drawing.Size(52, 20);
            this.MenuItemHome.Text = "Home";
            this.MenuItemHome.Click += new System.EventHandler(this.MenuItemHome_Click);
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.lblManage);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(0, 60);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 495);
            this.panel1.TabIndex = 50;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(33, 65);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(15, 16);
            this.label8.TabIndex = 57;
            this.label8.Text = ">";
            // 
            // lblManage
            // 
            this.lblManage.AutoSize = true;
            this.lblManage.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblManage.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblManage.Location = new System.Drawing.Point(54, 65);
            this.lblManage.Name = "lblManage";
            this.lblManage.Size = new System.Drawing.Size(65, 16);
            this.lblManage.TabIndex = 52;
            this.lblManage.Text = "Start Chat";
            this.lblManage.Click += new System.EventHandler(this.lblManage_Click);
            this.lblManage.MouseLeave += new System.EventHandler(this.lblManage_MouseLeave);
            this.lblManage.MouseHover += new System.EventHandler(this.lblManage_MouseHover);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 16);
            this.label1.TabIndex = 51;
            this.label1.Text = "Main Menu";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ControlDark;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(200, 27);
            this.panel2.TabIndex = 51;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(297, 6);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(240, 13);
            this.label4.TabIndex = 30;
            this.label4.Text = "© 2016 Developed By Inzamam Mashood";
            // 
            // panelFooter
            // 
            this.panelFooter.Controls.Add(this.label4);
            this.panelFooter.Location = new System.Drawing.Point(0, 561);
            this.panelFooter.Name = "panelFooter";
            this.panelFooter.Size = new System.Drawing.Size(809, 26);
            this.panelFooter.TabIndex = 23;
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel3.Controls.Add(this.lblTitle);
            this.panel3.Controls.Add(this.pictureBox1);
            this.panel3.Location = new System.Drawing.Point(206, 60);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(595, 100);
            this.panel3.TabIndex = 51;
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Comic Sans MS", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(370, 29);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(131, 31);
            this.lblTitle.TabIndex = 1;
            this.lblTitle.Text = "Start Chat";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(21, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(300, 91);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel4.Location = new System.Drawing.Point(206, 166);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(595, 10);
            this.panel4.TabIndex = 52;
            // 
            // panelInternetBrowsing
            // 
            this.panelInternetBrowsing.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panelInternetBrowsing.Controls.Add(this.label2);
            this.panelInternetBrowsing.Controls.Add(this.txtLog);
            this.panelInternetBrowsing.Controls.Add(this.txtServerIP);
            this.panelInternetBrowsing.Controls.Add(this.btnStart);
            this.panelInternetBrowsing.Location = new System.Drawing.Point(206, 174);
            this.panelInternetBrowsing.Name = "panelInternetBrowsing";
            this.panelInternetBrowsing.Size = new System.Drawing.Size(595, 385);
            this.panelInternetBrowsing.TabIndex = 53;
            this.panelInternetBrowsing.Visible = false;
            // 
            // txtLog
            // 
            this.txtLog.Location = new System.Drawing.Point(21, 36);
            this.txtLog.Multiline = true;
            this.txtLog.Name = "txtLog";
            this.txtLog.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.txtLog.Size = new System.Drawing.Size(549, 333);
            this.txtLog.TabIndex = 11;
            // 
            // txtServerIP
            // 
            this.txtServerIP.Location = new System.Drawing.Point(129, 9);
            this.txtServerIP.Name = "txtServerIP";
            this.txtServerIP.Size = new System.Drawing.Size(167, 20);
            this.txtServerIP.TabIndex = 9;
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(360, 7);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(162, 23);
            this.btnStart.TabIndex = 10;
            this.btnStart.Text = "Start Listening";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(72, 12);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 13);
            this.label2.TabIndex = 12;
            this.label2.Text = "Server IP";
            // 
            // StartChat
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(809, 586);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panelFooter);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.SubMenu);
            this.Controls.Add(this.MainMenu);
            this.Controls.Add(this.panelInternetBrowsing);
            this.Name = "StartChat";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Start Chat";
            this.Load += new System.EventHandler(this.Users_Load);
            this.SubMenu.ResumeLayout(false);
            this.SubMenu.PerformLayout();
            this.MainMenu.ResumeLayout(false);
            this.MainMenu.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panelFooter.ResumeLayout(false);
            this.panelFooter.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panelInternetBrowsing.ResumeLayout(false);
            this.panelInternetBrowsing.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private System.Windows.Forms.MenuStrip SubMenu;
        private System.Windows.Forms.ToolStripMenuItem menuItemDashboard;
        private System.Windows.Forms.ToolStripMenuItem menuItemManageUsers;
        private System.Windows.Forms.ToolStripMenuItem menuItemManageInventory;
        private System.Windows.Forms.ToolStripMenuItem menuItemManageEmployees;
        private System.Windows.Forms.ToolStripMenuItem menuItemManageSales;
        private System.Windows.Forms.ToolStripMenuItem menuItemExpenses;
        private System.Windows.Forms.MenuStrip MainMenu;
        private System.Windows.Forms.ToolStripMenuItem MenuItemLogout;
        private System.Windows.Forms.ToolStripMenuItem MenuItemHome;
        private System.Windows.Forms.ToolStripMenuItem logoutToolStripMenuItem;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panelFooter;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblManage;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panelInternetBrowsing;
        #endregion
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtLog;
        private System.Windows.Forms.TextBox txtServerIP;
        private System.Windows.Forms.Button btnStart;

    }
}