﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EClassRoom
{
    public partial class DashboardTeacher : Form
    {
        public DashboardTeacher()
        {
            InitializeComponent();
        }
        private void Dashboard_Load(object sender, EventArgs e)
        {
            Dashboard db = new Dashboard();
        }
        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            MainForm mf = new MainForm();
            mf.FormClosed += new FormClosedEventHandler(mf_FormClosed);
            mf.Show();
            this.Hide();
        }
        private void mf_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Close();
        }

        private void pbUsers_MouseHover(object sender, EventArgs e)
        {
            panelUsers.BackColor = Color.LimeGreen;
        }

        private void pbUsers_MouseLeave(object sender, EventArgs e)
        {
            panelUsers.BackColor = Color.SkyBlue;
        }
        private void pbInventory_MouseHover(object sender, EventArgs e)
        {
            panelInvertory.BackColor = Color.LimeGreen;
        }

        private void pbInventory_MouseLeave(object sender, EventArgs e)
        {
            panelInvertory.BackColor = Color.SkyBlue;
        }
        
        private void pbSales_MouseHover(object sender, EventArgs e)
        {
            panelSales.BackColor = Color.LimeGreen;
        }

        private void pbSales_MouseLeave(object sender, EventArgs e)
        {
            panelSales.BackColor = Color.SkyBlue;
        }
        private void pbCustomers_MouseHover(object sender, EventArgs e)
        {
            panelCustomers.BackColor = Color.LimeGreen;
        }

        private void pbCustomers_MouseLeave(object sender, EventArgs e)
        {
            panelCustomers.BackColor = Color.SkyBlue;
        }
        private void pbExpenses_MouseHover(object sender, EventArgs e)
        {
            panelExpenses.BackColor = Color.LimeGreen;
        }

        private void pbExpenses_MouseLeave(object sender, EventArgs e)
        {
            panelExpenses.BackColor = Color.SkyBlue;
        }

        private void pbUsers_Click(object sender, EventArgs e)
        {
            ManageNotesTeacher us = new ManageNotesTeacher();
            us.FormClosed += new FormClosedEventHandler(us_FormClosed);
            us.Show();
            this.Hide();
        }
        private void us_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Close();
        }

        private void menuItemManageUsers_Click(object sender, EventArgs e)
        {
            ManageNotesTeacher us = new ManageNotesTeacher();
            us.FormClosed += new FormClosedEventHandler(us_FormClosed);
            us.Show();
            this.Hide();
        }

        private void MainMenu_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void SubMenu_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void pbInventory_Click(object sender, EventArgs e)
        {
            ManageDocumentsTeacher md = new ManageDocumentsTeacher();
            md.FormClosed += new FormClosedEventHandler(us_FormClosed);
            md.Show();
            this.Hide();
        }

        private void menuItemManageInventory_Click(object sender, EventArgs e)
        {
            ManageDocumentsTeacher md = new ManageDocumentsTeacher();
            md.FormClosed += new FormClosedEventHandler(us_FormClosed);
            md.Show();
            this.Hide();
        }

        private void menuItemManageEmployees_Click(object sender, EventArgs e)
        {
            InternetBrowsingTeacher ib = new InternetBrowsingTeacher();
            ib.FormClosed += new FormClosedEventHandler(us_FormClosed);
            ib.Show();
            this.Hide();
        }

        private void menuItemManageSales_Click(object sender, EventArgs e)
        {
            QuickQuiz aq = new QuickQuiz();
            aq.FormClosed += new FormClosedEventHandler(us_FormClosed);
            aq.Show();
            this.Hide();
        }

        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MainForm mf = new MainForm();
            mf.FormClosed += new FormClosedEventHandler(mf_FormClosed);
            mf.Show();
            this.Hide();
        }

        private void menuItemExpenses_Click(object sender, EventArgs e)
        {
            StartChat aq = new StartChat();
            aq.FormClosed += new FormClosedEventHandler(mf_FormClosed);
            aq.Show();
            this.Hide();
        }

        private void manageStudentsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ManageStudents aq = new ManageStudents();
            aq.FormClosed += new FormClosedEventHandler(mf_FormClosed);
            aq.Show();
            this.Hide();
        }

        private void pbEmployees_Click(object sender, EventArgs e)
        {
            ManageStudents aq = new ManageStudents();
            aq.FormClosed += new FormClosedEventHandler(mf_FormClosed);
            aq.Show();
            this.Hide();
        }

        private void pbSales_Click(object sender, EventArgs e)
        {
            InternetBrowsingTeacher ib = new InternetBrowsingTeacher();
            ib.FormClosed += new FormClosedEventHandler(us_FormClosed);
            ib.Show();
            this.Hide();
        }

        private void pbCustomers_Click(object sender, EventArgs e)
        {
            QuickQuiz aq = new QuickQuiz();
            aq.FormClosed += new FormClosedEventHandler(us_FormClosed);
            aq.Show();
            this.Hide();
        }

        private void pbExpenses_Click(object sender, EventArgs e)
        {
            StartChat aq = new StartChat();
            aq.FormClosed += new FormClosedEventHandler(mf_FormClosed);
            aq.Show();
            this.Hide();
        }
    }
}
