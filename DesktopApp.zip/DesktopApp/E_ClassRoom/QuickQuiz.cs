﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Windows.Forms;

namespace EClassRoom
{
    public partial class QuickQuiz : Form
    {
        DBManager objDBManager = new DBManager();
        public QuickQuiz()
        {
            InitializeComponent();
        }

        private void lblManage_MouseHover(object sender, EventArgs e)
        {
            lblManage.ForeColor = Color.Red;
        }

        private void lblManage_MouseLeave(object sender, EventArgs e)
        {
            lblManage.ForeColor = Color.Black;
        }

        private void lblManage_Click(object sender, EventArgs e)
        {
            lblManage.Font = new Font("Microsoft Sans Serif", 9, FontStyle.Bold);
            lblTotal.Font = new Font("Microsoft Sans Serif", 9, FontStyle.Regular);
            panelInternetBrowsing.Visible = true;
            panelHistory.Visible = false;

            lblTitle.Text = "Current Quiz";

            listBoxAvailable.Items.Clear();
            DataTable dt = objDBManager.ReturnDataTable("select * from tblquestion where IsApproved = 'Yes'");
            for (int a = 0; a < dt.Rows.Count; a++)
            {
                listBoxAvailable.Items.Insert(a, dt.Rows[a]["ID"].ToString() + ": " + dt.Rows[a]["Question"].ToString());
            }
        }

        private void Users_Load(object sender, EventArgs e)
        {
            panelInternetBrowsing.Visible = true;
            DataTable dt = objDBManager.ReturnDataTable("select q.Question from tblquiz t join tblquestion q on t.Question = q.ID where Teacher_id ='" + Global.UserId + "' AND IsActive = 'Yes'");
            if (dt.Rows.Count > 0)
            {
                lblCurrentQuiz.Text = HttpUtility.UrlDecode(dt.Rows[0]["Question"].ToString());
            }

            listBoxAvailable.Items.Clear();
            dt = objDBManager.ReturnDataTable("select * from tblquestion where IsApproved = 'Yes'");
            for (int a = 0; a < dt.Rows.Count; a++)
            {
                listBoxAvailable.Items.Insert(a, dt.Rows[a]["ID"].ToString() + ": " + dt.Rows[a]["Question"].ToString());
            }
        }

        private void menuItemManageUsers_Click(object sender, EventArgs e)
        {
            ManageNotesTeacher mn = new ManageNotesTeacher();
            mn.FormClosed += new FormClosedEventHandler(db_FormClosed);
            mn.Show();
            this.Hide();
        }

        private void db_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Close();
        }

        private void menuItemDashboard_Click(object sender, EventArgs e)
        {
            DashboardTeacher db = new DashboardTeacher();
            db.FormClosed += new FormClosedEventHandler(db_FormClosed);
            db.Show();
            this.Hide();
        }

        private void MenuItemHome_Click(object sender, EventArgs e)
        {
            MainForm mf = new MainForm();
            mf.FormClosed += new FormClosedEventHandler(db_FormClosed);
            mf.Show();
            this.Hide();
        }

        private void lblTotal_MouseEnter(object sender, EventArgs e)
        {
            lblTotal.ForeColor = Color.Red;
        }

        private void lblTotal_MouseLeave(object sender, EventArgs e)
        {
            lblTotal.ForeColor = Color.Black;
        }

        private void lblTotal_Click(object sender, EventArgs e)
        {
            lblTotal.Font = new Font("Microsoft Sans Serif", 9, FontStyle.Bold);
            lblManage.Font = new Font("Microsoft Sans Serif", 9, FontStyle.Regular);
            panelInternetBrowsing.Visible = false;
            panelHistory.Visible = true;

            lblTitle.Text = "Available Quizes";
        }

        private void menuItemManageInventory_Click(object sender, EventArgs e)
        {
            ManageDocumentsTeacher md = new ManageDocumentsTeacher();
            md.FormClosed += new FormClosedEventHandler(db_FormClosed);
            md.Show();
            this.Hide();
        }

        private void menuItemManageEmployees_Click(object sender, EventArgs e)
        {
            InternetBrowsingTeacher ib = new InternetBrowsingTeacher();
            ib.FormClosed += new FormClosedEventHandler(db_FormClosed);
            ib.Show();
            this.Hide();
        }

        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MainForm mf = new MainForm();
            mf.FormClosed += new FormClosedEventHandler(db_FormClosed);
            mf.Show();
            this.Hide();
        }

        private void menuItemExpenses_Click(object sender, EventArgs e)
        {
            StartChat aq = new StartChat();
            aq.FormClosed += new FormClosedEventHandler(db_FormClosed);
            aq.Show();
            this.Hide();
        }

        private void manageStudentsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ManageStudents aq = new ManageStudents();
            aq.FormClosed += new FormClosedEventHandler(db_FormClosed);
            aq.Show();
            this.Hide();
        }

        private void btnCreateQuiz_Click(object sender, EventArgs e)
        {
            if (listBoxAvailable.SelectedIndex != -1)
            {
                string id = listBoxAvailable.Items[listBoxAvailable.SelectedIndex].ToString().Split(':')[0];
                string query = "Update tblquiz set IsActive = 'No'";
                objDBManager.ExecuteCommandwithNoReturn(query);

                query = "Insert into tblquiz(Question, Teacher_id,QuizDate) Values( " + id + ",'" + Global.UserId + "','" + DateTime.Now.ToString("dd-MM-yyyy hh:mm:ss") + "') ";
                objDBManager.ExecuteCommandwithNoReturn(query);

                DataTable dt = objDBManager.ReturnDataTable("select q.Question from tblquiz t join tblquestion q on t.Question = q.ID where Teacher_id ='" + Global.UserId + "' AND IsActive = 'Yes'");
                if (dt.Rows.Count > 0)
                {
                    lblCurrentQuiz.Text = HttpUtility.UrlDecode(dt.Rows[0]["Question"].ToString());
                }
                panelInternetBrowsing.Visible = true;
                panelHistory.Visible = false;
            }
        }
    }
}
