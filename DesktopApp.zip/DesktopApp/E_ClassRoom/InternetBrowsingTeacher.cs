﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EClassRoom
{
    public partial class InternetBrowsingTeacher : Form
    {
        public InternetBrowsingTeacher()
        {
            InitializeComponent();
        }

        private void lblManage_MouseHover(object sender, EventArgs e)
        {
            lblManage.ForeColor = Color.Red;
        }

        private void lblManage_MouseLeave(object sender, EventArgs e)
        {
            lblManage.ForeColor = Color.Black;
        }

        private void lblManage_Click(object sender, EventArgs e)
        {
            lblManage.Font = new Font("Microsoft Sans Serif", 9, FontStyle.Bold);
            panelHistory.Visible = true;

            lblTitle.Text = "Internet Browsing";
        }

        private void Users_Load(object sender, EventArgs e)
        {
            panelHistory.Visible = true;
        }

        private void menuItemManageUsers_Click(object sender, EventArgs e)
        {
            ManageNotesTeacher mn = new ManageNotesTeacher();
            mn.FormClosed += new FormClosedEventHandler(db_FormClosed);
            mn.Show();
            this.Hide();
        }

        private void db_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Close();
        }

        private void menuItemDashboard_Click(object sender, EventArgs e)
        {
            DashboardTeacher db = new DashboardTeacher();
            db.FormClosed += new FormClosedEventHandler(db_FormClosed);
            db.Show();
            this.Hide();
        }

        private void MenuItemHome_Click(object sender, EventArgs e)
        {
            MainForm mf = new MainForm();
            mf.FormClosed += new FormClosedEventHandler(db_FormClosed);
            mf.Show();
            this.Hide();
        }
        private void menuItemManageInventory_Click(object sender, EventArgs e)
        {
            ManageDocumentsTeacher md = new ManageDocumentsTeacher();
            md.FormClosed += new FormClosedEventHandler(db_FormClosed);
            md.Show();
            this.Hide();
        }

        private void menuItemManageSales_Click(object sender, EventArgs e)
        {
            QuickQuiz aq = new QuickQuiz();
            aq.FormClosed += new FormClosedEventHandler(db_FormClosed);
            aq.Show();
            this.Hide();
        }

        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MainForm mf = new MainForm();
            mf.FormClosed += new FormClosedEventHandler(db_FormClosed);
            mf.Show();
            this.Hide();
        }

        private void menuItemExpenses_Click(object sender, EventArgs e)
        {
            StartChat aq = new StartChat();
            aq.FormClosed += new FormClosedEventHandler(db_FormClosed);
            aq.Show();
            this.Hide();
        }

        private void manageStudentsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ManageStudents aq = new ManageStudents();
            aq.FormClosed += new FormClosedEventHandler(db_FormClosed);
            aq.Show();
            this.Hide();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            WebBrowser.GoBack();
        }

        private void btnForward_Click(object sender, EventArgs e)
        {
            WebBrowser.GoForward();
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            WebBrowser.GoHome();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            WebBrowser.Refresh();
        }

        private void btnGo_Click(object sender, EventArgs e)
        {
            WebBrowser.Navigate(txtAddress.Text);
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            WebBrowser.Stop();
        }

        private void WebBrowser_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            lblTop.Text = WebBrowser.DocumentTitle;
            txtAddress.Text = WebBrowser.Url.ToString();
        }

        private void WebBrowser_ProgressChanged(object sender, WebBrowserProgressChangedEventArgs e)
        {
            lblBottom.Text = WebBrowser.StatusText;
        }

        private void txtAddress_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                WebBrowser.Navigate(txtAddress.Text);
            }
        }
    }
}
